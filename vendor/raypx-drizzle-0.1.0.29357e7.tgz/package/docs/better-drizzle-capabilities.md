# better-drizzle 能力清单与合并方案

本清单按源码而非宣传语核对 better-drizzle **0.3.0**，固定提交为
[`f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d`](https://github.com/almeidazs/better-drizzle/tree/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d)。
核对范围包括发布 manifest、公开入口、全部 model/client 方法、查询和写入编译器、
关系执行器、事务、错误处理，以及所有插件。即使 Raypx 尚无调用，也保留其设计位置。
上游采用 Apache-2.0；改编代码须保留来源、版权和完整许可证。

状态定义：**已实现**只指当前 `@raypx/drizzle` 的实际导出；**规划**表示已收录的
扩展工作，不能据此导入 API；**原生复用**表示采用 Drizzle 公共接口；
**上游仅声明**表示该提交有类型或 preset，却没有对应完整实现；
**库存保留，当前实施范围外**表示保留源码与语义清单，当前不开发兼容实现。

数据库范围固定为 PostgreSQL，驱动仅 postgres.js（npm `postgres`），Drizzle 入口为
`drizzle-orm/postgres-js`。不兼容 `pg`/node-postgres；Bun SQL、PGlite 及其他驱动没有支持计划。
本库存完整保留上游 MySQL/SQLite 的入口、能力、类型和错误编码；这些专有实现均为
**库存保留，当前实施范围外**，不因上游已有实现而进入本包路线图。
下文无额外说明的“规划”只覆盖通用与 PostgreSQL/postgres.js 能力。

最终公开入口与统一语义以 [合并方案](merge-plan.md) 为准。本库存使用 `./query` 表示
未来查询层（内部包括 client、mutation、predicate、ordering、pagination、prepared、lock、
transaction 和 raw execution 模块），使用 `./relations` 表示关系层；这些内部能力不各自
新增发布入口。PostgreSQL 表达式统一放 `./postgres`，可选插件归入 `./plugins/*`；
不规划 `./mysql`/`./sqlite`。
仅第1节“上游入口”和附录列出的路径是在描述上游发布契约。

本文的 `./client`、`./mutations`、`./prepared`、`./predicates` 等名称是能力分组建议，
并非已发布 subpath。最终公开模块以 [统一合并方案](merge-plan.md) 为准：
查询能力统一由 `./query` 提供，关系由 `./relations` 提供。

## 1. 入口和兼容边界

上游 [package.json](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/package.json)
提供 ESM/CJS 和声明文件，公开以下 **14 个入口**：

| 上游入口         | 内容                                                                   | toolkit 合并位置与状态                                  |
| ---------------- | ---------------------------------------------------------------------- | ------------------------------------------------------- |
| `better-drizzle` | `better`、`param`、错误 API、所有根类型、`version`                     | `./query`、`./errors`；除严格 PG 唯一冲突识别外均为规划 |
| `./plugins`      | `definePlugin` 和完整插件作者类型                                      | `./plugins/*` 的作者 API，规划，保持可选依赖            |
| `./rules`        | `rules`、`merge`、`safe`、`recommended`、`strict`、规则类型、`version` | `./plugins/*` 的 rules 模块，规划；按实现证据拆解规则   |
| `./timestamps`   | `timestamps`、配置类型、`version`                                      | `./plugins/timestamps`，规划                            |
| `./uuid`         | `uuids`、UUID v4/v7 策略、配置类型、`version`                          | `./plugins/uuid`，规划                                  |
| `./uuid/mysql`   | `buuid` 自定义二进制 UUID 列                                           | 库存保留，当前实施范围外                                |
| `./uuid/sqlite`  | `buuid` 自定义二进制 UUID 列                                           | 库存保留，当前实施范围外                                |
| `./soft-delete`  | `softDelete`、恢复方法和可见性类型、`version`                          | `./plugins/soft-delete`，规划                           |
| `./tenant`       | `tenant`、tenant client 和配置类型、`version`                          | `./plugins/tenant`，规划，安全模块独立验收              |
| `./cache`        | `cache`、store/serializer/TTL/失效接口、`version`                      | `./plugins/cache`，规划                                 |
| `./cache/redis`  | `redis` 和已有 Redis client 的适配类型                                 | `./plugins/cache/redis`，规划                           |
| `./zod`          | `zod`、`ZodModelExtensionResolver`、模型 schema/输入类型、`version`    | `./plugins/*` 的 Zod adapter，规划                      |
| `./ata`          | `ata`、JSON Schema/编译验证器/registry/residue 类型、`version`         | `./plugins/*` 的 ATA adapter，规划                      |
| `./eslint`       | 默认插件、`rules`、`configs`、三个 preset、规则 key 类型、`version`    | 独立静态检查适配层，规划                                |

`src/plugins/{zod,ata}/schemas.ts` 包含 registry 构建函数，但 manifest **没有**
`./zod/schemas` 或 `./ata/schemas` 出口。它们是可提炼的内部能力，不能误写成上游已发布入口。
`uuidv4`/`uuidv7` 也只在 UUID 插件内部导出，没有独立发布入口。

上游 peer 为 `drizzle-orm >=1.0.0-rc.4 <1.0.0-rc.5`，不覆盖当前 toolkit 测试的
`1.0.0-rc.5-5935859`。插件还有可选 Zod 3.25/4、ata-validator、ESLint 9 和
TypeScript parser peer。其 ORM facade 依赖 `db._.relations`、关系对象的
`sourceColumns`/`targetColumns`/`through`/`throughTable` 和 junction 的 `column._.column`；
参考 [context.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/context.ts)
与 [factory.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/factory.ts)。
合并时重建显式 PostgreSQL 表/关系描述，通过公共 API 和调用方传入的元数据工作；
执行核心直接接收 PostgresJsDatabase/PostgresJsTransaction，不建多驱动 adapter。
禁止复制私有客户端探测；postgres.js Sql/TransactionSql 由消费者创建和管理，
不得通过 Drizzle session 推断它们。真实 PostgreSQL、postgres.js 与声明测试决定 RC 兼容范围。

## 2. Model CRUD 与批量写入

依据 [公开 delegate](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/delegate.ts)
和 [operations.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/operations.ts)。
本节全部为 `./query` **规划**；只有组成 UPSERT 的显式 `excludedColumn(s)`
已在 `./postgres` 实现，不表示已有 CRUD facade。

| 能力                    | 上游实际语义                                                                                                                           | 合并与扩展约束                                                                                             |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------- |
| `findMany`              | 返回行数组，过滤、投影、关系、排序、take/skip、cursor、锁                                                                              | 共用表达式编译器；保留原生 query 可组合性                                                                  |
| `findFirst` / `findOne` | 返回首行或 null；`findOne` 是首行读取语义                                                                                              | 一个规范实现，别名仅在兼容层保留                                                                           |
| `findUnique`            | 要求 where 由主键或唯一键锁定一行；否则拒绝                                                                                            | 使用显式唯一键描述，不能把任意 where 命名为 unique                                                         |
| `count` / `exists`      | count 数量；exists 只检查有无匹配，使用 limit 1                                                                                        | 与 drizzle-plus count 合并；精确定义 count 数值解码                                                        |
| `create`                | 插入并返回记录；可选 select/include；skipDuplicates 可返回 null                                                                        | duplicate skip 与普通 create 的返回类型分别声明                                                            |
| `createMany`            | 原生多行插入，返回 `BatchResult { count, data? }`；可 chunk；可 skipDuplicates/投影                                                    | 参数上限驱动分块；跨块原子性必须由事务策略明确承诺                                                         |
| `update`                | 修改至多一行；非唯一 where 通过限定一行路径处理；无行返回 null；关系写入必须精确匹配一行                                               | 默认要求唯一定位；如提供 first-match，必须显式排序和选择语义                                               |
| `updateMany`            | 同一更新数据应用到所有匹配行；可返回 scalar 投影；where 缺失或编译为空时返回 count 0                                                   | 统一同值 bulk 更新；规范入口空 where 默认拒绝，上游 no-op 仅留兼容层；全表操作显式 opt-in                  |
| `updateEach`            | `by` 列 + 输入行 + 每列 callback；用 CASE 为各行写不同值；附加 where；scalar select；`onEmpty: return/throw`                           | 与两上游的同值 `updateMany` 区分；drizzle-plus 的 set callback、filter/limit 和 CTE 选行不是异值输入行更新 |
| `delete`                | 至多删除一行，返回被删行或 null；无 RETURNING 方言先读                                                                                 | 非唯一定位规则同 update；保留事务/并发语义                                                                 |
| `deleteMany`            | 删除匹配行，返回 count 和可选 data；空 where 返回 0                                                                                    | 规范入口空 where 默认拒绝；上游 no-op 仅作兼容语义，不默认删除全部数据                                     |
| `upsert`                | `where/create/update`；能推断唯一冲突时原生 UPSERT，其余 read-then-write；关系分支也先读                                               | 规范 API 默认显式 conflict target，自动推断只作 opt-in；回退路径单列为非原子策略，不能默默切换             |
| `upsertMany`            | 原生批量 UPSERT；显式 target；update 可键名单、对象/SQL 或 callback 的 excluded/current-column 表达式；optional select/batchSize/where | 与 drizzle-plus UPSERT 统一；明确目标、更新键与冲突更新 predicate，禁自动全列覆盖                          |
| `skipDuplicates`        | boolean 或显式 target/targetWhere；PG/SQLite conflict-do-nothing，MySQL insert-ignore 限制由实现检查                                   | 仅实现 PostgreSQL ON CONFLICT DO NOTHING；拒绝吞掉其他约束错误；MySQL/SQLite 行为仅库存                    |
| `.throw(factory?)`      | 单行 read/write 的 null 转默认 RESULT_NOT_FOUND 或调用方错误                                                                           | 与 drizzle-plus `orThrow` 合并为独立结果解包；当前 `first`/`inserted` 不是完整兼容别名                     |

`BatchResult.count` 不能直接当跨方言严格受影响行数：MySQL `upsertMany` 在源码中返回
提交的输入行数，部分没有 RETURNING 的写入先 count 再写，并发时有竞争窗口。
规范批量 count 表示实际受影响行数；输入行数、预读匹配数量和返回行不能冒充它。
这些差异保留为上游事实，MySQL/SQLite 不进入实施。PostgreSQL 执行器使用 RETURNING
或已验证的 postgres.js RowList.count 获取实际 count；附加统计字段的 API 形态另行设计。
`updateEach` 需额外验证重复 by key、null key、参数限额和
CASE 顺序；真实事务测试覆盖同时更新和 count 偏差。

## 3. 查询表达式、投影与关系

依据 [query 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/query.ts)、
[utils 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/utils.ts)、
[compiler.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/query/compiler.ts)
和 [relations.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/relations.ts)。

| 能力             | 完整范围                                                                                                                                                             | toolkit 路线与状态                                                                                     |
| ---------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| Structured where | 标量直接相等；`AND`/`OR` 数组；`NOT` 对象/数组；也接受 SQL/SQLWrapper                                                                                                | `./query` 规划；空 AND/OR、undefined、null 三值逻辑须固定                                              |
| 标量过滤         | `equals/in/notIn/not/lt/lte/gt/gte`；按字段类型限制                                                                                                                  | `./query` 规划；未知字段运行时拒绝，不能静默掉成空 where                                               |
| 字符串过滤       | `contains/startsWith/endsWith`、`mode: default/insensitive`；大小写与 LIKE 编译按方言变化                                                                            | 规划 PostgreSQL `%/_/escape` 与 ILIKE；所有 pattern 模式经 postgres.js 验证                            |
| PG native array  | `equals/has/hasEvery/hasNone/hasSome/containedBy/isEmpty/length/not/some/every/none`；length 可比较过滤，元素可 scalar filter                                        | `./postgres`（array 内部模块）规划；验证 PostgreSQL 多维数组、null/空数组与 postgres.js 解码           |
| PG JSONB 路径    | 根据 `$type` 推导 dotted scalar path/value；`json` 显式 path map 或 dotted shorthand；值与 path 分别绑定；scalar eq/list/比较/pattern/not；运行时只识别 `PgJsonb` 列 | `./postgres` **已实现部分**：`jsonValue/jsonText/jsonType/jsonNumber/jsonBoolean`；完整 typed DSL 规划 |
| select/include   | scalar 和嵌套关系投影；include 保留全部 scalar；任意嵌套层 select/include 互斥；返回类型据 projection 推导                                                           | `./query`/`./relations` 规划；与 drizzle-plus `$without`/选择工具共用一个投影模型                      |
| 关系 `_count`    | 对 to-many 关联的计数 projection 和 optional where，many-to-many 经过 junction                                                                                       | `./relations` 规划；匹配目标与 junction 的全部 scope                                                   |
| 关系条件         | many 的 `some/every/none`；one 的 `is/isNot`（含 null）；相关 EXISTS/NOT EXISTS 或优化 membership 子查询                                                             | `./relations` 规划；固定 vacuous every、SQL null 与无关联的区别                                        |
| scalar 排序      | 单对象或对象数组，`asc/desc`，可显式 `nulls:first/last`；MySQL 通过额外表达式模拟 null 顺序                                                                          | `./query` 规划 PostgreSQL 原生 NULLS FIRST/LAST，统一 cursor 比较；MySQL 模拟仅库存                    |
| 关系排序         | one 可递归指定关联字段；many 只支持 `_count:asc/desc`，使用相关 scalar 子查询                                                                                        | `./relations` 规划；不得改变 root 行数，测 self relation 和多层 alias                                  |
| 关系读取         | one/many/many-to-many（`.through()`）加载；支持 nested 过滤/排序/分页/投影；执行器有 deferred hydration；simple one 存在 joined fast path                            | `./relations` 规划；不宣称总是一条 SQL，记录执行计划和 roundtrip 数                                    |
| 关系创建         | scalar insert + existing relation `connect`；one selector 或 many selector/list                                                                                      | `./relations` 规划，唯一 selector + 同一事务；该提交没有嵌套 create/connectOrCreate API                |
| 关系更新         | one `connect/disconnect:true/set:selector                                                                                                                            | null`；many `connect/disconnect`或`set:list`；junction/referencing-side 更新                           | `./relations` 规划；连接前检查目标可见性，不绕过 tenant/scope；禁止模糊 selector |
| `$where`         | 纯编译为 Drizzle SQL/undefined；**不自动应用插件过滤**                                                                                                               | `./query` 规划；命名与文档明确“未应用 scope”，另提供显式 scoped compile                                |

JSON 标量转换不能直接复制：上游把 `jsonb_typeof(...) = 'number'` 与 `::numeric`
放在 AND 两侧，SQL 优化器不保证短路顺序。当前 helper 使用 CASE，把缺失、JSON null、
异型值转换为 SQL null，并提供实际 decoder。后续还需覆盖大数/精度、路径包含点号、
数组下标、空 path、动态 path 和未知 schema；路径数组为基础接口，dotted DSL 为可选便捷层。

## 4. 原子写入表达式与分页

依据 [operations.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/operations.ts)
和 [compiler.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/query/compiler.ts)。

| 能力              | 上游语义                                                                                                                                  | 合并路线                                                                                                                               |
| ----------------- | ----------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| 数值原子 mutation | `set/increment/decrement/multiply/divide`；表达式在数据库执行                                                                             | `./query` 规划；固定组合顺序、0 除和 nullable 语义                                                                                     |
| boolean mutation  | `{ toggle:true }`                                                                                                                         | `./query` 规划，定义 null 如何处理                                                                                                     |
| PG array mutation | `append/prepend/remove/replace/addUnique`；每个输入是互斥策略，支持 scalar/list                                                           | `./postgres`（array 内部模块） 规划；定义 addUnique 的元素顺序、重复值和 null                                                          |
| JSONB mutation    | 全值替换、SQL、`json` path map、dotted path map，编译为 `jsonb_set`；递归补 object parent；拒绝空/重叠 path、undefined 和不可 JSON 编码值 | `./postgres`（JSON 内部模块） 规划；上游会把异型 parent 换成 object，合并需明确替换策略；删除 vs JSON null、数组下标和 null 列独立定义 |
| offset `paginate` | page/perPage/limit 与 take/skip；page 从 1 起，page 与 skip 互斥；data + total/pageCount/hasNext/hasPrevious                              | `./query` 规划；total 与 data 的一致性通过可选 snapshot 事务明确                                                                       |
| keyset `cursor`   | after/before 互斥；scalar cursor 对象含每个 orderBy 字段；多列词典序、null 排序、主键默认顺序、方向反转、limit+1 与存在性 probe           | 与 drizzle-plus cursor 合并为 `./query` 规划；确定唯一 tie-breaker、null/时间精度和 SQL-expression order support                       |
| read cursor 参数  | findMany/count/exists 等可接受 cursor，prepared 可绑定整个 cursor object                                                                  | `./query` 规划，复用排序与 predicate 编译                                                                                              |

上游 relation sort 不支持 cursor，且 token 为原始 scalar 对象，没有用户、过滤器或
权限 scope 绑定。通用库只提供序列化/比较机制，业务可注入 token binding/签名策略；
Raypx 现有 actor/query-bound cursor 保留在 DB，不能被 generic cursor 隐式替换。

## 5. 锁、事务与 raw SQL

依据 [factory.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/factory.ts)、
[事务类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/transaction.ts)、
[raw 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/raw.ts)
和 [lock 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/query.ts)。
本节全部 **规划/原生复用**，当前 helpers 不管理连接或执行事务。

| 能力                | 上游范围                                                                                                        | 统一决策                                                                                                            |
| ------------------- | --------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| row lock            | update/share/noKeyUpdate/keyShare，skipLocked/noWait 互斥，PG table targeting；SQLite 拒绝；可 transactionsOnly | `./query` 复用 PostgreSQL 原生 `.for`；验证 postgres.js 事务内锁竞争/连接归属；不改变业务 claim/fence               |
| query shape 限制    | lock 与 include 存在限制；锁错误规范化                                                                          | 显式 capability table，不静默去锁或拆出无锁 relation query                                                          |
| transaction         | callback tx、nested savepoint、rollback(reason)、afterCommit/afterRollback；SQLite 有显式 begin/savepoint 路径  | `./query` 直接组合 PostgresJsDatabase.transaction 与 PostgresJsTransaction.transaction/savepoint；SQLite 路径仅库存 |
| transaction options | isolationLevel、readOnly、timeoutMs、signal、meta/context、name/comment；unsupported options ignore/throw/warn  | 按 PostgreSQL isolation/read-only/局部 timeout 实现；不支持选项明确拒绝；AbortSignal 不等于 postgres.js 取消        |
| retry               | attempts、on(deadlock/serializationFailure/connectionError)、delayMs(number/function)                           | 自动重试仅显式启用；连接错误的提交结果可能未知，不能默认安全重试非幂等 callback                                     |
| lifecycle callback  | nested commit 后合并到父事务，最外层提交后运行；回滚清理相应 callbacks                                          | 仅 commit 后副作用；callback 失败不得让已提交事务再次重试                                                           |
| `$raw`              | tagged SQL/SQLWrapper，optional map、name/comment/meta/timeout/signal；返回 rows                                | `./query` 规划，复用绑定 SQL；raw 绕过 model CRUD transform，但有独立 raw hooks                                     |
| `$executeRaw`       | 同样接受绑定 SQL，返回 `{rowsAffected?}`                                                                        | 验证 postgres.js RowList.count/RETURNING 的实际受影响行数；无法确定时保留 unknown，不建立多驱动分支                 |
| `$rawUnsafe`        | 默认禁止，显式 allowUnsafe；字符串 `?` placeholder + 参数                                                       | 仅可选兼容层；默认公开扩展只接受 Drizzle SQL，不能手写天真的 placeholder 替换                                       |
| raw global config   | enabled/allowUnsafe/requireComment/timeoutMs/log/unsupportedOptions                                             | 消费者显式配置日志、取消和超时；日志输出先脱敏                                                                      |

锁和事务无需改 Drizzle prototype。事务 wrapper 绑定公开的 PostgresJsTransaction，
不得切回根 db 或其他连接。调用方 Sql/TransactionSql 生命周期由调用方拥有；
已有外层 tx 的自动 commit 不能被库观察，afterCommit/缓存失效须显式接入消费者通知。
验证最外层 commit、rollback、嵌套 savepoint、hook 顺序与连接归属。

诊断超时使用 PostgreSQL transaction-local statement_timeout/lock_timeout，失败后等待
真实回滚和资源清理；只有明确拥有 postgres.js PendingQuery 才使用其公开 `.cancel()`，
测试 57014、取消竞态和连接恢复。不读取 Drizzle 私有 session，也不能把 Promise 超时或
AbortSignal guard 包装成“数据库操作必然停止”的保证。

## 6. Context、scope、hooks 与插件作者 API

依据 [scopes.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/scopes.ts)、
[plugins.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/plugins.ts)、
[插件执行器](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/plugins.ts)
及 [hooks 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/hooks.ts)。
全部为 `./query`/`./plugins/*` **规划**。

- Client：`better(db, options)`；按表 key 访问；`repository(name)` 接受 TS key 或数据库表名；
  `extends(object|factory)` 的扩展重新绑定 context/transaction 派生 client，并检查键冲突。
- Context：`$withContext(meta)` 克隆并合并默认 metadata；call meta 覆盖同名 key。
  metadata 只是显式上下文，不自动成为授权依据。
- Delegate：`$model {name,dbName,hasColumn}`、`$state`、`$withState` 和
  `$withoutPlugins({keepScopes?})`。后者默认同时移除 scope，是必须显式审计的绕过能力。
- Scope：`PluginScopeDefinition` 支持 `key/model/root/missing/mismatch/bypass/session/rawSession`；
  model 定义 `columns/immutable/nullable/stamp/upsert/where`。应用到根表、嵌套关系、
  relation filter、relation count/sort、mutation 和 conflict update；安全 scope 只能 AND
  组合，用户过滤不能覆盖。stamp 写入并验证列，immutable 拒绝修改 scope 列。
- 生命周期：`beforeCreate/afterCreate`、`beforeUpdate/afterUpdate`、
  `beforeDelete/afterDelete`、`beforeQuery/afterQuery`、`onError`；
  `beforeRaw/afterRaw/onRawError`；`beforeTransaction/afterTransactionCommit/`
  `afterTransactionRollback/onTransactionError`。上下文包含 args/result/table/model/meta/
  tx/scope/state；不得默认整包输出到日志。
- 插件作者：`definePlugin`；`id/name/version/description/options`；
  `config.dialects/requires.columns`；`generated` 定义生成列并改变 create 输入可选性；
  `setup/transform/intercept/hooks/extendClient/extendModel/operationArgs/scope`；
  type-level model/client resolver 与 strict hidden model。拦截器按插件数组顺序，外层先执行。
  初始化验证 duplicate id、dialect、所需列/类型、扩展键和 operation arg 冲突。
  setup context 提供 `addHook/addTransform/isColumnExists`、schema/dialect/models/plugin；
  client extension context 提供 `withScope`，model extension context 提供绑定 delegate。
  `PluginTransform` 返回 undefined 可跳过操作，intercept 可替代结果或跳过 after hooks，
  合并时必须约束这类短路对安全检查和提交后副作用的影响。

合并后插件管线共用一套执行语义，不叠加 drizzle-plus 的 prototype hooks。建议处理顺序为
参数校验 → 不可绕过 scope → 可选 transform → 执行 → 结果校验 → 事务提交 → 提交后副作用；
必须记录各阶段是否能改写 args、短路结果或绕过其他阶段。认证/权限 scope 与可选缓存、
timestamp transform 分离，generic bypass 不能移除安全 scope。

## 7. Prepared 与 EXPLAIN

依据 [prepared.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/prepared.ts)、
[prepared 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/prepared.ts)、
[explain.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/client/explain.ts)
与 [explain 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/explain.ts)。

| 能力                   | 实际范围                                                                                                                                          | toolkit 状态与合并                                                                                                |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| `param(name)`          | typed placeholder，按 read args 自动推导 execute 参数；支持 where/take/skip/page/perPage/after/before                                             | `./query` 规划，复用原生 sql.placeholder/prepare                                                                  |
| `.prepare(name?)`      | count/cursor/exists/findFirst/findMany/findOne/findUnique/paginate；编译 read，执行时 missing/unknown param 检查，保留 projection/hydration/hooks | 规划；验证 postgres.js prepare 开/关、重复执行、绑定参数和事务连接；不声称 write 或全部 relation shape 可 prepare |
| Prepared execute       | `.execute(values, {meta?})`；单行支持 throw；statement 暴露 name；PreparedParams/PreparedResult 推导                                              | 规划；每次执行重验 scope/tenant 并运行 hooks；cache key 包含绑定值、scope、schema/shape/version                   |
| `.explain(options?)`   | 仅 read；paginate 可含 data/total，cursor 含条件 probe，报告 deferred relation/probe                                                              | `./diagnostics` **部分已实现**：独立 PG EXPLAIN 构造和安全指标汇总；facade read plan 集成规划                     |
| EXPLAIN 方言           | PG flags；MySQL EXPLAIN/EXPLAIN ANALYZE；SQLite EXPLAIN QUERY PLAN；报告 ignoredOptions                                                           | 仅 PostgreSQL/postgres.js 实施；MySQL/SQLite 库存保留，当前实施范围外                                             |
| EXPLAIN options/result | analyze/verbose/costs/timing/summary/timeoutMs/name/comment；原始 result 包含 SQL、params、raw plan、options                                      | 默认 diagnostics 只出指标 allowlist；详细计划显式 opt-in 且消费者负责访问控制                                     |

上游 `name` 被拼成 PG EXPLAIN 的 NAME 选项，合并不能照搬未经支持矩阵验证的 SQL。
`analyze` 会实际执行语句，必须显式启用并记录 read-only/事务策略。上游包含 SQL/参数/
predicates/raw plan 的结果不得作为默认日志或对外 RPC 返回；当前独立 helper 保留脱敏指标边界。

## 8. 错误分类

依据 [errors.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/shared/errors.ts)。

| 能力                                       | 上游范围                                                                                                                   | 合并状态                                                                                                                                     |
| ------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| `isDatabaseError` / `getDatabaseErrorInfo` | 递归 cause，识别 pg/sqlite/mysql/unknown；读取 code/errno/message/constraint/table/column 并可能从 message 推断            | `./errors` 规划 postgres.js 结构化 SQLSTATE 分类，不解析敏感 message；SQLite/MySQL 编码仅库存                                                |
| `isUniqueViolation`                        | PG23505、SQLite unique/PK、MySQL duplicate；可指定 constraint                                                              | **已实现 postgres.js 严格子集**：必传 constraint，仅匹配 SQLSTATE 和 constraint_name，保护 cause 循环；不兼容 constraint，不解析敏感 message |
| `isForeignKeyViolation`                    | PG23503、SQLite FK、MySQL1451/1452；可指定 constraint                                                                      | 规划 postgres.js 对应 PostgreSQL SQLSTATE；SQLite/MySQL 分支库存保留，当前实施范围外                                                         |
| `isNotNullViolation`                       | PG23502、SQLite notnull、MySQL1048；可指定 column                                                                          | 规划 postgres.js 对应 PostgreSQL SQLSTATE；SQLite/MySQL 分支库存保留，当前实施范围外                                                         |
| `isCheckViolation`                         | PG23514、SQLite check、MySQL3819；可指定 constraint                                                                        | 规划 postgres.js 对应 PostgreSQL SQLSTATE；SQLite/MySQL 分支库存保留，当前实施范围外                                                         |
| `BetterDrizzleError`                       | 统一 error code、HTTP-like status、operation/table/driver/details/cause；`BetterDrizzleTransactionRollbackError` 有 reason | 通用错误类型规划；HTTP status 由应用 adapter 决定；默认诊断/日志不输出 query/params/cause，调用方可保留原始错误排障                          |

错误编码分组全部保留：cache、database/dialect、JSONB/array、hooks/invalid args、locks、
prepared params/unsupported、plugin id/column/dialect/extension/operation-arg、raw enabled/
unsafe/query/options/comment/timeout/abort、repository/result/table runtime、tenant、transaction
lifecycle/rollback/retry相关错误、unique where 和 unknown。完整编码名见本文件附录。

## 9. 所有插件

| 插件                                                                                                                                                                                                                                                                   | 完整能力                                                                                                                                                                                                                                                               | 合并状态与验收重点                                                                                                       |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| [timestamps](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/timestamps/index.ts)                                                                                                                                | app/database mode；createdAt/updatedAt key；model override/false；注入 clock，一次操作共用时间；覆盖 create/batch/update/upsert                                                                                                                                        | 规划；数据库 default/onUpdate 原生复用；固定保持 createdAt、upsert update、chunk clock 语义                              |
| [uuid](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/uuid/index.ts)                                                                                                                                            | UUIDv4 或进程内单调 UUIDv7；默认 id，可逐 model 改列/禁用；生成列在 create 类型中变可选                                                                                                                                                                                | 规划；别把进程内顺序宣传成分布式全局顺序，保留调用方值与库可移植性                                                       |
| [uuid/mysql](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/uuid/mysql.ts)、[uuid/sqlite](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/uuid/sqlite.ts) | `buuid` 把 UUID string 转换为16字节 binary/blob 并解码；独立 customType                                                                                                                                                                                                | 库存保留，当前实施范围外；不新增 MySQL/SQLite 二进制列入口                                                               |
| [soft-delete](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/soft-delete/index.ts)                                                                                                                              | 默认 deletedAt/deletedById；soft/hard；without/with/only；delete→update；restore/restoreById；nested读的scope；upsert故意不按deleted过滤                                                                                                                               | 规划；硬删除/恢复需显式策略；保留其他安全scope；校验唯一索引与恢复冲突；root opt-in不自动传播nested                      |
| [tenant](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/tenant/index.ts)                                                                                                                                        | 单/多 tenant columns；global/model override/nullable；missing throw/allow；strict 类型隐藏；$tenant逐步缩窄、禁止重设；$withoutTenant必须reason；insert stamp/immutable更新；关联/junction/filter/count/sort/upsert scope；raw deny/allow/set-local；PG RLS set_config | 规划；default fail-closed；应用tenant过滤不能代替DB RLS政策；raw trusted/bypass显式审计；消费者提供实际RLS policy        |
| [cache](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/cache/index.ts)                                                                                                                                          | 可插拔批量get/set/delete store；serializer；全局/逐model/逐call启用；TTL、negative TTL、refresh、customkey、tags、vary、namespace/version/versionTtl、maxSize、afterHooksOnHit；模型/关联依赖失效；write/raw hints；$cache.clear/invalidate；store出错回源             | 规划；权限scope/tenant/metadata必须进key；事务内读的隔离策略明确；不得共享未提交结果；验证跨进程versions初始化与失效竞争 |
| [cache/redis](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/cache/redis/index.ts)                                                                                                                              | 适配Bun send/ioredis call/node-redis sendCommand或注入command；MGET/SET EX/DEL；cluster逐key命令；不创建/关闭连接                                                                                                                                                      | 规划；独立adapter，不强依赖任一Redis客户端；cluster故障和部分写失败验证                                                  |
| [zod](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/zod/index.ts)                                                                                                                                              | Drizzle列→Zod3/4；`$zod` 暴露create/update/where/select/orderBy/query/pagination/upsert schema；字段override/extend/omit/partial；coerce与unknownKeys strip/passthrough/strict；逐操作/逐call validate；input/output推导；投影/关系结果验证，保留relation commands     | 规划；与Drizzle原生schema转换共用，Zod可选peer；不能把strip当业务allowlist；显式支持customType                           |
| [ata](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/ata/index.ts)                                                                                                                                              | JSON Schema构建/一次编译，可precompile；模型列override/false；operation/call validate；$ata包含count/create/cursor/delete/deleteMany/orderBy/pagination/query/row/select/update/where；Date/BigInt/Buffer residues补充检查；JSON schema可独立输出                      | 规划；与Zod共用列描述和schema registry接口；unknown列明确不保证校验；JSON schema不直接表达全部JS值                       |
| [rules](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/rules/shared/plugin.ts)                                                                                                                                  | runtime guardrails、severity、model/operation scope、reporter/onViolation、preset和merge                                                                                                                                                                               | 规划；区分下一节实际evaluator与声明未实现项；reporter默认只收脱敏字段                                                    |
| [eslint](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/index.ts)                                                                                                                                        | 26条AST规则和safe/recommended/strict配置                                                                                                                                                                                                                               | 规划；独立适配包/入口，toolkit不新增第二套项目linter；研究Oxlint外部JS插件或兼容ESLint消费方                             |

该提交 cache 的写入失效已经排到**最外层事务提交后**，savepoint 回滚清掉相应待失效项，
不能误写成“事务提交前失效”。需要进一步验证的是跨进程依赖版本创建、commit至失效之间窗口、
并行read填缓存、scope隔离、serializer精度/日期/BigInt与cache hit下的hook一致性。
源码没有发布内存store入口；store是接口，不能把示例/测试store写成内置memory产品能力。

## 10. Runtime rules：实现与声明分别记录

依据 [options 类型](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/rules/types.ts)、
[evaluators](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/rules/shared/plugin.ts)
与 [presets](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/rules/shared/presets.ts)。

| 分组              | 上游有 evaluator 的规则                                                                                                                                          | 类型/preset 中声明、无对应 evaluator                                                                                                                 |
| ----------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| 破坏性操作        | noDeleteManyWithoutWhere、noUpdateManyWithoutWhere、noDeleteWithoutWhere、noUpdateWithoutWhere、noEmptyWhere                                                     | —                                                                                                                                                    |
| 范围和分页        | noUnboundedFindMany、requireExplicitLimit、maxLimit、requireOrderByForLimit、requireOrderByForPagination、requireOrderByForCursor、requireStableOrderByForCursor | —                                                                                                                                                    |
| 关系加载          | maxIncludeDepth、maxIncludeRelations                                                                                                                             | —                                                                                                                                                    |
| 锁                | requireTransactionForLock、noLockWithInclude、noInvalidLockCombination、requireOrderByForSkipLocked、requireLimitForSkipLocked                                   | —                                                                                                                                                    |
| Raw               | noRawUnsafe、requireRawComment、requireRawTimeout、noRawMutation、noRawWithoutTransaction                                                                        | —                                                                                                                                                    |
| Tenant            | requireTenantContext、noTenantBypassWithoutSystem、noTenantColumnOverride、requireTenantOnCreate、requireTenantOnUpdate、requireTenantOnDelete                   | —                                                                                                                                                    |
| 敏感数据          | noSensitiveSelect、requireExplicitSensitiveAccessReason                                                                                                          | noSensitiveFieldsInLogs                                                                                                                              |
| 软删除            | noHardDeleteOnSoftDeleteModel、requireHardDeleteReason、noQueryDeletedWithoutExplicitOptIn                                                                       | requireRestoreReason                                                                                                                                 |
| Bypass/system     | noSystemModeWithoutReason                                                                                                                                        | noWithoutPlugins、noPluginBypassWithoutReason                                                                                                        |
| Audit context     | —                                                                                                                                                                | requireAuditContext、noAuditLogForIgnoredModelWrite                                                                                                  |
| Nested write      | —                                                                                                                                                                | maxNestedWriteDepth、requireTransactionForNestedWrite、requireUniqueWhereForConnect、requireUniqueWhereForConnectOrCreate、noAmbiguousNestedRelation |
| Aggregate/groupBy | —                                                                                                                                                                | requireWhereForAggregate、requireLimitForGroupBy、maxGroupByLimit、requireOrderByForGroupByLimit                                                     |
| Prepared          | —                                                                                                                                                                | noDynamicPreparedShape、noPreparedNameConflict                                                                                                       |
| 方言              | —                                                                                                                                                                | noUnsupportedDialectFeature、noSilentDialectFallback                                                                                                 |
| 长操作            | requireTimeoutForLongRunningOperation                                                                                                                            | —                                                                                                                                                    |

`RulesPluginOptions` 共 **56 条 rule 配置**，其中 **37 条有 evaluator，19 条仅声明**。
存在声明不能推导出 `aggregate/groupBy/connectOrCreate/nested create` 已有运行时能力；
model 方法全集在第2节。合并需要把这19条列作独立待实现任务，并先实现其所依赖的操作。
空 where guard 和 unique selector 等通用安全边界应进入执行内核，即使可选 rules 插件被绕过
也不能删除；可选规则仅做风格/限额或更严格的应用策略。

## 11. ESLint 全部 26 条规则

这些是静态 AST 提示，不是授权或 SQL 安全证明。动态 args、别名、spread 和第三方封装的
覆盖率须单独记录；每条规则将来由统一规则描述生成runtime与静态适配器，避免语义漂移。

| 源文件                                                                                                                                              | 规则 ID 全集                                                                                                                                                                            |
| --------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [destructive.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/destructive.ts) | no-delete-many-without-where、no-delete-without-where、no-update-many-without-where、no-update-without-where、no-empty-where                                                            |
| [query.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/query.ts)             | no-unbounded-find-many、require-explicit-limit、max-limit、require-order-by-for-limit、require-order-by-for-pagination、require-order-by-for-cursor、require-stable-order-by-for-cursor |
| [include.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/include.ts)         | max-include-depth、max-include-relations                                                                                                                                                |
| [locks.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/locks.ts)             | no-lock-with-include、no-invalid-lock-combination、require-order-by-for-skip-locked、require-limit-for-skip-locked                                                                      |
| [raw.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/raw.ts)                 | no-raw-unsafe、require-raw-comment、require-raw-timeout、no-raw-mutation                                                                                                                |
| [sensitive.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/sensitive.ts)     | no-sensitive-select、require-explicit-sensitive-access-reason                                                                                                                           |
| [plugins.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/plugins/eslint/rules/plugins.ts)         | no-without-plugins、no-plugin-bypass-without-reason                                                                                                                                     |

## 12. 合并实施顺序与验收

1. **纯函数基线**：列投影、显式excluded表达式、PG严格错误分类、结果解包、CASE JSON scalar、
   PG EXPLAIN构造和脱敏指标。只有实际export +类型/行为测试通过的能力标已实现。
2. **表达式与批量写入**：scalar/JSONB/array predicate与mutation、safe ordering、
   批量UPSERT/updateEach。统一drizzle-plus与better-drizzle同义能力；native builder是基础。
3. **分页与诊断**：统一stable keyset、offset count一致性选项、prepared read原生适配器、
   多statement诊断、postgres.js prepare/事务/超时矩阵。业务token binding留注入接口。
4. **显式关系与可选client**：公开元数据描述、select/include/count、关系条件与排序、
   connect/disconnect/set事务；再实现typed facade。禁止私有Drizzle字段作为默认通道。
5. **scope和插件**：先不可绕过scope/tenant与tx commit lifecycle，再timestamp/uuid/soft-delete；
   cache、Zod、ATA、rules、静态检查分别验收。每种插件可独立消费/关闭，安全scope单独授权绕过。
6. **未实现上游声明与新扩展**：19条声明规则、aggregate/groupBy/nested create/connectOrCreate
   保留完整需求；这些是toolkit未来增量设计，不是假冒的上游现有实现。

每个阶段必需：发布产物干净工程消费、ESM/declaration测试、负向类型断言、真实PG约束/并发/
事务/JSON异型数据测试。数据库测试只覆盖 PostgreSQL + postgres.js；PG17/18 能力 gate
与实际 postgres.js/Drizzle peer 版本记录明确。MySQL/SQLite 专有能力保留库存、当前范围外，
不增加后续多方言/多驱动阶段；Redis 仍需对应可选插件的独立实测。
插件依赖使用独立入口和optional peer，不使基础SQL helpers加载validator/Redis/ESLint。
对上游有意改变的语义记录迁移示例，尤其是updateMany/updateEach、批量count、空where、
scope bypass、非原子upsert和诊断数据。每包独立发版不意味着兼容性无需检查。

## 13. 公开类型与错误编码索引

下列索引按固定提交的 `src/types/index.ts` 的 star exports 和各插件发布入口整理。
根入口历史上也公开了大量 runtime结构类型；toolkit不必把它们全部作为永久公开接口，
但必须记录并在兼容适配层决定保留/替代/移入internal。类型名列表不能当做已实现export列表。

### 根入口类型与运行时作者 API

| 固定源码                                                                                                                             | 公开声明全集                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| ------------------------------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [database.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/database.ts)       | `UpdateResult`、`DeleteResult`、`OffsetPaginationResult`、`CursorPaginationResult`、`OffsetPaginationOptions`、`CursorPaginationOptions`、`OrderBy`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| [delegate.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/delegate.ts)       | `CreateDataInput`、`PgArrayMutationInput`、`NumericMutationInput`、`BooleanMutationInput`、`JsonbMutationField`、`UpdateScalarDataInput`、`UpdateDataInput`、`ThrowFactory`、`ThrowingWriteResult`、`ThrowingResult`、`PreparableRead`、`PreparableSingleRead`、`BatchResult`、`SkipDuplicatesColumn`、`SkipDuplicatesOption`、`CreateArgs`、`UpdateArgs`、`CreateManyArgs`、`UpdateManyArgs`、`TableColumnFor`、`UpdateEachRow`、`UpdateEachUpdateMap`、`UpdateEachArgs`、`DeleteManyArgs`、`DeleteArgs`、`UpsertArgs`、`UpsertManyTargetColumn`、`UpsertManyTarget`、`UpsertManyUpdateValue`、`UpsertManyExcluded`、`UpsertManyTableColumns`、`UpsertManyUpdateContext`、`UpsertManyUpdateStrategy`、`UpsertManyArgs`、`BetterDrizzleExtendsMethod`、`ExtendedClient`、`StrictClient`、`BetterRootClient`、`BetterDrizzleClient`、`BetterDrizzleModelDelegate`、`BetterTableConfig`、`BetterTableKey`、`BetterAliasKey`、`BetterRepositoryKey`、`BetterTableRelations`、`BetterRelationalConfig`、`BetterRecord`           |
| [explain.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/explain.ts)         | `ExplainOptions`、`ExplainOperation`、`ExplainStatement`、`ExplainResult`、`ExplainableResult`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| [hooks.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/hooks.ts)             | `QueryHookAction`、`CreateHookAction`、`UpdateHookAction`、`DeleteHookAction`、`HookAction`、`RawHookAction`、`HookStage`、`BeforeCreateHookContext`、`AfterCreateHookContext`、`BeforeUpdateHookContext`、`AfterUpdateHookContext`、`BeforeDeleteHookContext`、`AfterDeleteHookContext`、`BeforeQueryHookContext`、`AfterQueryHookContext`、`ErrorHookContext`、`BeforeTransactionHookContext`、`AfterTransactionCommitHookContext`、`AfterTransactionRollbackHookContext`、`TransactionErrorHookContext`、`BeforeRawHookContext`、`AfterRawHookContext`、`RawErrorHookContext`、`BetterClientOptions`、`BetterClientHooks`                                                                                                                                                                                                                                                                                                                                                                                                 |
| [plugins.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/plugins.ts)         | `PluginDialect`、`PluginState`、`PluginExtension`、`PluginColumnRequirement`、`PluginConfig`、`PluginGeneratedColumns`、`PluginMeta`、`PluginModelInfo`、`PluginModelRelation`、`PluginScopeModel`、`PluginScopeDefinition`、`ModelRegistry`、`PluginHookKind`、`PluginOperationArgsExtensionMap`、`PluginOperationInput`、`PluginInterceptContext`、`PluginIntercept`、`PluginTransactionHookContext`、`PluginTransactionErrorHookContext`、`PluginTransactionRollbackHookContext`、`PluginRawHookContext`、`PluginRawErrorHookContext`、`PluginHooks`、`PluginTransform`、`PluginSetupContext`、`PluginModelExtensionContext`、`PluginClientExtensionContext`、`Plugin`、`AnyPlugin`、`ModelExtensionTypeResolver`、`ClientExtensionTypeResolver`、`HiddenModelsOf`、`ClientExtensionOf`、`ModelExtensionOf`、`OperationArgsOf`、`GeneratedColumnsOf`、`UnionToIntersection`、`ClientExtensionsOf`、`PluginOperationArgsFor`、`OperationArgsExtensionsOf`、`OperationArgsWithPlugins`、`ModelExtensionsOf`、`definePlugin` |
| [prepared.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/prepared.ts)       | `PreparedParam`、`PreparedParamsFor`、`PreparedExecuteOptions`、`PreparedStatement`、`PreparedThrowingResult`、`PreparedSingleStatement`、`PreparableResult`、`PreparedParams`、`PreparedResult`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| [query.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/query.ts)             | `WhereInput`、`WhereArg`、`SelectInput`、`ScalarSelectInput`、`IncludeInput`、`OrderByInput`、`BetterMeta`、`CursorInput`、`LockMode`、`LockTableName`、`LockOption`、`BetterLockClientOptions`、`QueryArgs`、`CountArgs`、`ExistsArgs`、`PaginationArgs`、`CursorArgs`、`PayloadForArgs`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| [raw.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/raw.ts)                 | `RawOptions`、`RawOptionsExtensions`、`RawClientOptions`、`RawExecutionResult`、`RawSql`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| [runtime.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/runtime.ts)         | `DrizzleQueryDelegate`、`InsertBuilderLike`、`UpdateBuilderLike`、`DeleteBuilderLike`、`SelectQueryLike`、`DrizzleLikeDatabase`、`RuntimeClientExtensionFactory`、`RuntimeSchema`、`TableRuntime`、`ScopeEntry`、`PluginRuntimeBeforeHook`、`PluginRuntimeAfterHook`、`PluginRuntimeTransactionHook`、`PluginRuntimeTransform`、`PluginRuntimeIntercept`、`PluginRuntimeBucket`、`PluginRuntimeTransactionBucket`、`PluginRuntimeRawBucket`、`TransactionCallback`、`TransactionRuntime`、`RuntimeContext`、`WhereCompilerContext`、`CompilableWhere`、`NullableResult`、`JoinColumns`                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| [transaction.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/transaction.ts) | `TransactionIsolationLevel`、`TransactionRetryReason`、`TransactionRetryOptions`、`TransactionOptions`、`TransactionUnsupportedOptionsBehavior`、`BetterDrizzleTransactionRollbackError`、`BetterDrizzleTransactionClient`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| [utils.ts](https://github.com/almeidazs/better-drizzle/blob/f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d/src/types/utils.ts)             | `AnySchema`、`TablesConfig`、`TableKey`、`Singularize`、`AliasKey`、`DbNameKey`、`SourceKeyFromDbName`、`TableConfigFor`、`SafeKeys`、`TableFor`、`SelectModelFor`、`InsertModelFor`、`InsertInputFor`、`RelationKeysFor`、`ScalarKeysFor`、`RelationFor`、`RelatedNameFor`、`RelatedConfigFor`、`IsManyRelation`、`NonNullish`、`SortOrder`、`NullsOrder`、`SortConfig`、`QueryMode`、`Bindable`、`StringFilter`、`ComparableFilter`、`BooleanFilter`、`ScalarFilter`、`ScalarWhereField`、`ArrayFilter`、`ArrayWhereField`、`IsPgArrayColumn`、`IsPgJsonColumn`、`PgArrayKeysFor`、`IsUnknown`、`JsonScalarPath`、`JsonPathValue`、`JsonWhereInput`、`JsonDottedWhereInput`、`JsonMutationValue`、`JsonMutationPath`、`JsonMutationInput`、`JsonDottedMutationInput`                                                                                                                                                                                                                                                       |

`definePlugin`、`BetterDrizzleTransactionRollbackError` 为运行时值，其余索引主要为类型。
根错误入口公开 `DatabaseDriver`、`BetterDrizzleErrorCode`、`BetterDrizzleErrorOptions`、
`DatabaseErrorInfo`、`BetterDrizzleError` 和第8节的六个错误识别/解析函数。

### 插件公开类型

| 入口            | 类型全集                                                                                                                                                                                                                                                                                                                                             |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `./timestamps`  | `TimestampModelOptions`、`TimestampsOptions`                                                                                                                                                                                                                                                                                                         |
| `./uuid`        | `UuidsOptions`、`UuidVersion`                                                                                                                                                                                                                                                                                                                        |
| `./soft-delete` | `SoftDeleteDefaultVisibility`、`SoftDeleteMode`、`SoftDeleteOptions`、`SoftDeleteVisibility`                                                                                                                                                                                                                                                         |
| `./tenant`      | `TenantColumnKeys`、`TenantModelOverride`、`TenantRawMode`、`TenantMissingMode`、`TenantOptions`、`TenantValues`、`TenantBypassOptions`、`TenantMethod`、`TenantClientExtension`、`TenantScopedModels`、`TenantExtension`、`TenantGeneratedModels`                                                                                                   |
| `./cache`       | `CacheDuration`、`CacheStoreEntry`、`CacheStore`、`CacheSerializer`、`CacheReadOptions`、`CacheReadArg`、`CacheInvalidateHint`、`CacheWriteArg`、`CacheInvalidateTarget`、`CacheModelOptions`、`CacheVaryContext`、`CacheOptions`、`CacheClient`、`CacheClientExtension`、`CacheOperationArgs`                                                       |
| `./zod`         | `BetterDrizzleZodModelExtension`、`BetterDrizzleZodModelExtensionResolver`、`BetterDrizzleZodModelSchemas`、`ZodPluginBehavior`、`ZodPluginCursorInput`、`ZodPluginOptions`、`ZodPluginPaginationInput`、`ZodPluginQueryInput`、`ZodPluginTableSchemasConfig`、`ZodPluginValidateOptions`、`ZodModelExtensionResolver`                               |
| `./ata`         | `AtaCompiledSchema`、`AtaPluginOptions`、`AtaPluginTableConfig`、`AtaPluginValidateOptions`、`AtaValidateKey`、`BetterDrizzleAtaModelExtension`、`BetterDrizzleAtaModelSchemas`、`JsonSchema`、`ResidueKind`、`AtaSchemasRegistry`、`TableEntry`、`RowMode`、`RowValidator`、`AtaIssue`                                                              |
| `./rules`       | `RuleSeverity`、`RuleSetting`、`MaybeArray`、`RulesOperation`、`RulesModelName`、`RulesContextKey`、`RulesViolation`、`RulesReporter`、`ModelRuleScope`、`RulesPluginOptions`、`MergeRulesOptions`、`NormalizedRule`、`OperationContext`、`RuleKey`、`RuleEmit`、`RuleEvaluator`、`HookOperationContext`、`HookRawContext`、`HookTransactionContext` |
| `./eslint`      | `EslintBetterDrizzleRuleKey`                                                                                                                                                                                                                                                                                                                         |
| `./plugins`     | 根类型索引的 `plugins.ts` 全集                                                                                                                                                                                                                                                                                                                       |
| `./cache/redis` | `RedisCommand`、`RedisClientLike`、`RedisStoreOptions`                                                                                                                                                                                                                                                                                               |

`./uuid/mysql` 和 `./uuid/sqlite` 发布 `buuid` 运行时列构建器，不单独发布配置类型。
公开类型都追溯到第1节入口；内部 `TimestampMode`、`RestoreModelExtension`、
`ZodPluginOrderByInput` 等源码声明不应被误认为各入口已导出的命名类型。

### 错误编码全集

| 枚举 key                           | 字符串编码                            |
| ---------------------------------- | ------------------------------------- |
| `AfterCommitOutsideTransaction`    | `AFTER_COMMIT_OUTSIDE_TRANSACTION`    |
| `AfterRollbackOutsideTransaction`  | `AFTER_ROLLBACK_OUTSIDE_TRANSACTION`  |
| `CacheInvalidOptions`              | `CACHE_INVALID_OPTIONS`               |
| `CacheSerializationError`          | `CACHE_SERIALIZATION_ERROR`           |
| `CacheStoreError`                  | `CACHE_STORE_ERROR`                   |
| `CacheValueTooLarge`               | `CACHE_VALUE_TOO_LARGE`               |
| `DatabaseError`                    | `DATABASE_ERROR`                      |
| `DialectInferenceFailed`           | `DIALECT_INFERENCE_FAILED`            |
| `JsonbQueryUnsupported`            | `JSONB_QUERY_UNSUPPORTED`             |
| `JsonbMutationUnsupported`         | `JSONB_MUTATION_UNSUPPORTED`          |
| `ArrayQueryUnsupported`            | `ARRAY_QUERY_UNSUPPORTED`             |
| `ArrayMutationUnsupported`         | `ARRAY_MUTATION_UNSUPPORTED`          |
| `HookError`                        | `HOOK_ERROR`                          |
| `InvalidArgs`                      | `INVALID_ARGS`                        |
| `LockNotSupported`                 | `LOCK_NOT_SUPPORTED`                  |
| `LockRequiresTransaction`          | `LOCK_REQUIRES_TRANSACTION`           |
| `LockTimeout`                      | `LOCK_TIMEOUT`                        |
| `OperationError`                   | `OPERATION_ERROR`                     |
| `PreparedParamMissing`             | `PREPARED_PARAM_MISSING`              |
| `PreparedParamUnknown`             | `PREPARED_PARAM_UNKNOWN`              |
| `PreparedUnsupported`              | `PREPARED_UNSUPPORTED`                |
| `PluginDialectUnsupported`         | `PLUGIN_DIALECT_UNSUPPORTED`          |
| `PluginDuplicateId`                | `PLUGIN_DUPLICATE_ID`                 |
| `PluginExtensionConflict`          | `PLUGIN_EXTENSION_CONFLICT`           |
| `PluginOperationArgConflict`       | `PLUGIN_OPERATION_ARG_CONFLICT`       |
| `PluginRequiredColumnMissing`      | `PLUGIN_REQUIRED_COLUMN_MISSING`      |
| `PluginRequiredColumnType`         | `PLUGIN_REQUIRED_COLUMN_TYPE`         |
| `RawCommentRequired`               | `RAW_COMMENT_REQUIRED`                |
| `RawAborted`                       | `RAW_ABORTED`                         |
| `RawDisabled`                      | `RAW_DISABLED`                        |
| `RawInvalidQuery`                  | `RAW_INVALID_QUERY`                   |
| `RawTimeout`                       | `RAW_TIMEOUT`                         |
| `RawUnsafeDisabled`                | `RAW_UNSAFE_DISABLED`                 |
| `RawUnsafePlaceholderMismatch`     | `RAW_UNSAFE_PLACEHOLDER_MISMATCH`     |
| `RawUnsupportedOption`             | `RAW_UNSUPPORTED_OPTION`              |
| `RepositoryNotFound`               | `REPOSITORY_NOT_FOUND`                |
| `ResultNotFound`                   | `RESULT_NOT_FOUND`                    |
| `TableRuntimeNotFound`             | `TABLE_RUNTIME_NOT_FOUND`             |
| `TenantAlreadyScoped`              | `TENANT_ALREADY_SCOPED`               |
| `TenantMismatch`                   | `TENANT_MISMATCH`                     |
| `TenantRawDenied`                  | `TENANT_RAW_DENIED`                   |
| `TenantRequired`                   | `TENANT_REQUIRED`                     |
| `TransactionAborted`               | `TRANSACTION_ABORTED`                 |
| `TransactionLifecycleStateMissing` | `TRANSACTION_LIFECYCLE_STATE_MISSING` |
| `TransactionRuntimeNotInitialized` | `TRANSACTION_RUNTIME_NOT_INITIALIZED` |
| `TransactionRollback`              | `TRANSACTION_ROLLBACK`                |
| `TransactionsUnsupported`          | `TRANSACTIONS_UNSUPPORTED`            |
| `TransactionTimeout`               | `TRANSACTION_TIMEOUT`                 |
| `TransactionUnsupportedOption`     | `TRANSACTION_UNSUPPORTED_OPTION`      |
| `UniqueWhereRequired`              | `UNIQUE_WHERE_REQUIRED`               |
| `Unknown`                          | `UNKNOWN`                             |

这些编码仅用于上游能力追踪。toolkit 当前不会自动导出整套 BetterDrizzleError 或把
数据库错误包装为 HTTP 响应；新增错误 API 必须遵循第8节的精确识别和脱敏边界。
