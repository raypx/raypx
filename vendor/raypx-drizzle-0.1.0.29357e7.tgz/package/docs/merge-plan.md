# Drizzle 合并与扩展方案

状态：完整设计与能力库存已经纳入 Packages；当前版本仅实现下文明确标出的基础能力。
查询客户端、关系编译器和插件仍是计划，不是现有导出。所有能力都进入库存，
是否有 Raypx 调用点不影响收录。

## 目标与归属

仓库为 `raypx/packages`，首包 `@raypx/drizzle`。Packages 集中维护构建、测试、
文档和发布工具；每个包拥有独立版本、CHANGELOG 和 npm 发布产物。
Drizzle 的所有子路径属于同一个包、使用同一个版本。

扩展库面向使用 PostgreSQL 与 postgres.js（npm 包 `postgres`）的 Drizzle 应用。
Raypx 只是第一个消费者，不向库中搬入账号权限、
账务规则、Run lease/fence、业务错误、数据表、环境变量或迁移执行。
库不创建默认数据库连接，不读 `.env`，不修改全局查询原型。

## 固定来源与完整库存

| 来源                                                          | 版本/提交                                                 | 原始许可   | 接入边界                                           |
| ------------------------------------------------------------- | --------------------------------------------------------- | ---------- | -------------------------------------------------- |
| [drizzle-plus](https://github.com/alloc/drizzle-plus)         | `1.0.0-rc.8` / `5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9` | MIT        | 选择、SQL 表达式、CTE、查询扩展、类型工具          |
| [better-drizzle](https://github.com/almeidazs/better-drizzle) | `0.3.0` / `f93f1b7aa528fe2db4cddc92a047e7a0ae710a0d`      | Apache-2.0 | 查询语义、关系、批量写入、prepared、诊断与可选插件 |

逐项清单与源码证据分别在
[drizzle-plus 库存](drizzle-plus-capabilities.md)和
[better-drizzle 库存](better-drizzle-capabilities.md)。库存区分实际实现、仅声明的类型、
内部支撑代码和真正发布的入口，避免把 wildcard export 当成实际存在的产物。
保留完整许可、来源提交与修改说明，见 [NOTICE](../NOTICE.md)。

两者不能直接拼装：drizzle-plus 的许多功能依赖全局原型和查询内部状态；
better-drizzle 原始 peer 范围 `>=1.0.0-rc.4 <1.0.0-rc.5` 排除了当前 RC.5。
这份方案按能力合并 API 与语义，替换不稳定的实现机制。

### 固定的实现范围

数据库只实现 PostgreSQL，驱动只实现 postgres.js（npm `postgres`），Drizzle 入口为
`drizzle-orm/postgres-js`。`pg`/node-postgres 不兼容，也不增加抽象多驱动执行器。
Drizzle 官方 `pg-core` 表和 SQL 类型仍是 PostgreSQL 建模 API，不代表依赖 npm `pg`。
上游 MySQL/SQLite 的入口、函数、类型与内部差异继续完整记录，但统一标为
**库存保留，当前实施范围外**，不再规划 `./mysql`/`./sqlite` 或相应移植阶段。
纯表达式可组合不等于其他驱动已经受支持；不承诺 Bun SQL、PGlite 或任何其他驱动。

## 当前可用的基础层

| 子路径          | 已实现能力                                                       | 语义                                                        |
| --------------- | ---------------------------------------------------------------- | ----------------------------------------------------------- |
| `.`             | `withoutColumns`                                                 | 保留 Drizzle 列类型；不修改表对象                           |
| `./postgres`    | `excludedColumn`、`excludedColumns`                              | 显式更新字段；使用物理列名和 quoted identifier              |
| `./postgres`    | `jsonValue`、`jsonText`、`jsonType`、`jsonNumber`、`jsonBoolean` | 路径逐段绑定；CASE 保护标量转换；明确 SQL NULL 与 JSON null |
| `./errors`      | `isUniqueViolation`                                              | SQLSTATE + 精确约束；支持嵌套 cause 和循环保护              |
| `./results`     | `first`、`inserted`                                              | 空读返回 null；必须返回行的写入可显式报错                   |
| `./diagnostics` | `buildExplain`、`summarizePlan`                                  | 默认只规划；显式 ANALYZE；输出白名单指标                    |

ESM、声明和 sourcemap 一起构建，Drizzle 为 peer，不打进包内。
现阶段仅承诺 `drizzle-orm@1.0.0-rc.5-5935859`、`postgres@3.4.9` 与 PostgreSQL 17 的实测行为。原 `./pg` 子路径改为 `./postgres`，不保留别名。
没有 Node/Bun 专属运行时导入，也没有 Raypx 工作区运行时依赖。

## 统一模块设计

下列未来子路径是设计目标，除上表之外尚未导出。

| 模块                               | 合并内容                                                                              | 实现方式                                                                         |
| ---------------------------------- | ------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| `.` / `./sql`                      | 列投影、toSQL、CASE、coalesce/nullif、文本/数值/时间函数、公共类型                    | 可组合纯函数，Drizzle 公共 SQLWrapper 与显式 decoder                             |
| `./postgres`                       | cast、JSON 聚合/对象/路径/patch、excluded、VALUES、CTE materialization、UUID 时间函数 | PostgreSQL 专用 AST/表达式；逐项声明 PG 版本要求                                 |
| `./query`                          | CRUD、count/exists、分页、批量、prepared、锁、scopes                                  | 直接使用 PostgresJsDatabase/PostgresJsTransaction 的公开能力；显式创建局部客户端 |
| `./relations`                      | include/select、some/every/none/is、关系排序、nested connect/set/disconnect           | 一个关系规划器；显式 schema/relations 输入；读写同一事务                         |
| `./diagnostics`                    | PostgreSQL EXPLAIN 构造、结果摘要、计划比较                                           | SQL 构造与纯计划处理分离；postgres.js 执行器按显式句柄处理超时/取消              |
| `./plugins/*`                      | timestamps、uuid、rules、tenant、soft-delete、cache、validation                       | 显式注册、可独立 import；可选依赖只属于对应入口                                  |
| `./compat/plus`、`./compat/better` | 原始 API 名称和迁移映射                                                               | 调用统一实现，提供明确差异，不维护第二套编译器                                   |
| `./types`、`./testing`             | result/nullability/path/selection 类型、PostgreSQL 功能 gate 与测试助手               | 从统一 IR、公开 PG 表模型与 postgres.js 类型派生，不建立多驱动泛型体系           |

首次发布先保持一个 npm 包，通过 subpath 隔离能力。
只有当插件拥有不同维护周期、独立重依赖或单独消费者时，才考虑新 npm 包，
例如 `@raypx/drizzle-cache`。增加包必须明确独立版本与依赖约束。

## 重复能力的合并决定

| 重复区域                               | 合并后的统一语义                                                        | 对两个上游的处理                                                     |
| -------------------------------------- | ----------------------------------------------------------------------- | -------------------------------------------------------------------- |
| findUnique/findFirst/findOne           | `findFirst` 可空；`findUnique` 必须证明完整唯一键；`findOne` 仅兼容别名 | 只保留一个查询执行器；partial unique 必须连同谓词才能证明唯一性      |
| count/exists/findManyAndCount/paginate | count 与数据共享过滤 AST；offset 返回 total，keyset 默认不额外 count    | 页与 count 的一致性模式由调用方显式选择事务快照                      |
| `$cursor`/cursor                       | 多字段稳定 keyset，明确升降序、NULL 顺序、前后翻页                      | 统一谓词生成；游标 codec/context binding 由消费者注入                |
| create/createMany/upsert/upsertMany    | 单条与批量共享写入执行器；更新 keys 与 conflict target 显式             | 自动推测冲突目标作为明确 opt-in，不能默默覆盖业务字段                |
| updateMany                             | 多行使用相同 set；where/limit/order/returning 按 PostgreSQL 定义        | 与 `updateEach` 区分；不能把 plus 的 updateMany 误认为异值批量更新   |
| updateEach                             | 同一匹配键的每行不同值，统一 CASE 或 VALUES/JOIN 策略                   | 输入重复键、空输入、参数预算与分块事务必须有定义                     |
| orThrow/`.throw()`                     | 可空结果和必须存在的结果分离，可注入错误工厂                            | 不修改原 Promise/execute 原型；兼容方法只包装结果                    |
| JSON selection/JSONB compiler          | 显式 JSON 表达式、路径 IR 和 decoder；选择和过滤复用同一规则            | 避免隐藏 `.decoder` 或 `_getQuery` 内省；SQL NULL/JSON null 单独测试 |
| timestamps                             | UTC-aware 类型与默认赋值分别负责                                        | schema 默认值、写入插件和 SQL 当前时间不能相互覆盖                   |
| errors                                 | postgres.js 结构化 SQLSTATE 分类 + 消费者自己的业务映射                 | 保留原始错误可用于调用方排障；日志输出另走安全摘要                   |
| 类型工具                               | 一套 value/selection/filter/returning 类型                              | 公开兼容别名，不让两个复杂递归类型系统重复计算                       |

## 查询与关系层的详细边界

未来客户端形态示例；不是当前已导出的可运行 API：

```ts
// sql 由调用方通过 postgres(...) 创建；调用方负责 max/prepare、连接和关闭。
const db = drizzle({ client: sql, relations });
const extended = extendDatabase(db, {
  client: sql,
  tables,
  relations,
  plugins: [timestamps(options)],
});

await extended.transaction(async (tx) => {
  await tx.table(users).upsert({ data, target: [users.email], update: [users.name] });
});
```

- 传入 tables/relations/client；不设置可切换的 dialect/driver，也不通过 `db._`、
  session、dialect 私有字段发现元数据或底层连接。执行核心输入为公开的
  `PostgresJsDatabase<TRelations>` 或 `PostgresJsTransaction<TRelations>`，使用
  select/insert/update/delete/execute/transaction 等公共能力。
- 原生 `db` 不被修改；transaction wrapper 必须重新绑定到原生 tx，所有查询、
  子关系写入、锁和 hooks 都使用它。应用显式传入的 tx 不能被另一连接替换。
- postgres.js `Sql` 的创建、pool 大小、prepare 配置、连接关闭由调用方负责；
  扩展库不调用共享 client.end()。显式 raw execution 可接收调用方拥有的 Sql 或
  TransactionSql；TransactionSql 只在对应事务/savepoint 生命周期内使用，不暴露 pool
  关闭 API，也不通过 Drizzle 事务内部字段构造或推断这个句柄。
- 过滤 IR 保留 AND/OR/NOT 与关系节点。复用查询的合并策略必须声明：
  用于授权的条件以 AND 合并，不能通过后续对象覆盖同字段来解除前置限制。
- include/select 共享一个关系读取计划，按 relation node 批量读取；避免逐行查询。
  关系计数、父过滤和排序的 SQL 与子记录分页是不同能力，分别验证。
- 单条 update/delete 必须保证最多一行；bulk 全表操作要求显式授权式参数，
  不把“where 为空”在不同入口解释成全表、静默 no-op 或其他行为。
  原 better-drizzle 的无条件 bulk no-op 保留在兼容层并说明差异。
- 批量 count 表示 PostgreSQL 实际 affected rows；不能把发送行数冒充插入行数。
  利用 RETURNING 或 postgres.js 已验证的 RowList.count 获取结果，明确 conflict-do-nothing、
  upsert、触发器和空输入的计数语义，不增加多驱动 count adapter。
- connect/disconnect/set 的已有实现纳入移植；nested create、connectOrCreate、
  groupBy/aggregate 等仅在上游有声明而无 evaluator 的区域明确标为新开发。

## 游标与 prepared 的合并

游标统一为 `{ version, order, values, binding }` 的可序列化 IR。
必须包含唯一 tie-breaker，验证日期精度、缺失值、类型与排序方向。
NULLS FIRST/LAST 和 SQL 表达式排序通过显式 order descriptor 提供 decoder，
不从任意查询的私有 selectedFields 推断。

框架仅生成 seek SQL、页边界和游标 payload。签名、加密、actor/query binding
由 codec/context 注入；Raypx 保留现有毫秒对齐和权限绑定策略。
offset/page-count 和 keyset 两种模式分别导出，禁止不显式声明的默认全量 count。

prepared read 使用当前 RC 的 PostgreSQL builder `.prepare()` 与 placeholder，
补类型化参数清单、缺失/多余参数校验和同一结果 shape。postgres.js 的 prepare 配置、
查询重用、事务连接和事务模式 PgBouncer 的部署条件由调用方控制；Drizzle 的 prepared
对象不自动承诺服务器上存在具名 prepared statement。必须测试 prepare 开/关、参数绑定、
重复执行、单连接事务与回滚，不能从 API 名称推断驱动行为。
权限或 tenant scope 必须每次执行重新验证，before/after hook 按每次执行运行。
不能因为上游在 prepare 时执行 before hook，就把动态访问上下文冻结在编译阶段。
prepared 写入、关系预加载和完整 hook 生命周期在 postgres.js/PostgreSQL 实测通过后再开放。

## 插件与事务生命周期

每个插件声明 PostgreSQL 最低版本、读/写操作、参数变换、结果变换与必需 context；
不声明可切换的数据库驱动或多方言支持。
实例配置只绑定当前扩展客户端，没有全局注册表。

| 插件              | 合并/扩展规则                                                                              |
| ----------------- | ------------------------------------------------------------------------------------------ |
| timestamps / uuid | 显式列配置；区分应用生成与数据库生成；PG18 的 uuidv7 单独 capability gate                  |
| rules             | 先移植真实 evaluator；声明-only 规则作为待实现功能，类型不可承诺运行时执行                 |
| tenant            | 外部传入 tenant context；queries/relations/raw/transactions 一致执行；RLS 为显式执行器能力 |
| soft-delete       | 默认读过滤、删除转写和 includeDeleted 分开；关联加载也应用；不擅自改变 FK/唯一约束         |
| cache / Redis     | keys 包含 scope/tenant/参数/投影和插件版本；失效在最外层 commit 成功后，回滚不广播         |
| Zod / ATA         | 同一 validation contract 的独立 adapter；从公共列 metadata 构建；schema policy 可覆盖      |
| ESLint / Oxlint   | 共享语义规则清单，分别实现解析器 adapter；不把 ESLint runtime 带进库根入口                 |

上游 cache 已有 afterCommit 延迟失效机制，移植时保留；新增验证关注并发 reader、
跨进程失效、失败重试与事务中读的一致性，不能以 TTL 代替授权隔离。
任何外部副作用（cache、日志、网络）都不能在失败事务中伪装成已提交。

事务 API 包装 PostgresJsDatabase.transaction；嵌套调用复用
PostgresJsTransaction.transaction 的 savepoint，绝不回退到根 db。
最外层原生事务 promise 成功后才执行 afterCommit；回滚丢弃待提交副作用并执行
对应 afterRollback；savepoint 回滚只清除该层工作，savepoint 成功不等于外层提交。
测试覆盖 commit、callback 抛错、显式 rollback、嵌套成功/回滚、连接归属与 hook 顺序。
调用方直接传入已有 Drizzle tx 或 TransactionSql 时，库无法观察外层提交；
须由消费者显式接入 commit/rollback 通知，否则禁止声称自动 afterCommit、禁止提前广播缓存失效。

raw 接口默认只接受参数化 SQL。SQL 文件/不安全文本入口必须显式标注并可关闭。
Promise.race 超时只停止等待，不等于数据库取消。Drizzle 事务内通过公开 execute
设置 transaction-local statement_timeout/lock_timeout；超时后等待真实失败和回滚完成，
不能把连接留在失败事务中。只有执行器明确持有调用方传入的 postgres.js PendingQuery，
才使用其公开 `.cancel()` 并验证取消竞态、SQLSTATE 57014 和连接后续可用性；不从
Drizzle 私有 session 提取句柄，也不宣称 AbortSignal 天然支持驱动取消。
诊断执行必须测试显式 ANALYZE、只读事务、锁等待、超时、取消后回滚和连接恢复；
当前纯构造/摘要 helper 本身不管理连接、不提供取消保证。

## SQL 函数与 decoder 规则

- 文本、数学、NULL、当前时间等所有原有 helper 进入库存；通用与 PostgreSQL 能力
  逐类迁入纯函数模块，验证 PostgreSQL 的参数次序、NULL、空字符串和取整行为。
  MySQL/SQLite 特有实现保留库存和语义对照，当前实施范围外。
- cast 使用封闭的 PostgreSQL 类型映射或显式 trusted PG type descriptor。
  bigint/numeric 不默认伪装成 number；精度转换必须由调用方选择 decoder。
- JSON 聚合定义空集合返回 null 还是 []，显式区分左连接 NULL 行过滤。
  聚合顺序、DISTINCT、FILTER、日期转换都有独立测试，decoder 由 selection 提供。
- VALUES、scalar subquery、alias、recursive/materialized CTE 以纯 AST/factory 实现。
  不替换 Drizzle 的全局 dialect/buildWithCTE，不使用 `_getQuery`。
- 查询直接暴露的 Date 与 JSON 中的字符串是不同契约。嵌套 JSON decoder 只转换
  selection 明确标记的字段，不扫描任意 payload 的日期形状。

## 实施阶段与验收

| 阶段              | 交付范围                                                                                         | 完成条件                                                                                            |
| ----------------- | ------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------- |
| A：当前基础层     | 已实现基础 helper、独立包构建、完整库存、本合并设计、独立发版配置                                | 类型/单测、postgres.js/PG17 消费者测试、仓库外 tarball 安装、Bun/Node import、许可证与 exports 检查 |
| B：SQL 完整层     | 18 个通用函数、CASE/selection/JSON 聚合、VALUES、CTE、时间类型工具                               | SQL 与解码用例逐项覆盖；PG17/18 功能 gate；所有表达式经 postgres.js 执行验证                        |
| C：统一查询层     | CRUD、唯一性、count/exists、offset/keyset、updateEach/upsertMany、prepared 与锁                  | postgres.js prepared 配置、真实并发/锁、事务回滚、批量冲突、NULL 排序与动态 scope 测试              |
| D：关系与插件     | include/filters/sorts/count、关系写入；timestamps/uuid/rules/tenant/soft-delete/validation/cache | 跨层事务和 tenant/软删一致性；插件顺序、commit/rollback、缓存竞争、缺少 evaluator 的类型修复        |
| E：兼容与开发工具 | PostgreSQL 范围内的 plus/better 兼容入口、开发检查插件、迁移指南                                 | 库存逐行区分已实现/计划/范围外；postgres.js、PG17/18 与 Drizzle peer 实测矩阵                       |

阶段不按“Raypx 是否用得上”删减库存；通用与 PostgreSQL 能力按依赖关系与验证成本排序。
MySQL/SQLite 入口、类型、实现差异与声明能力全部保留，状态为“库存保留，当前实施范围外”，
不把它们安排成后续移植阶段。node-postgres（`pg`）、Bun SQL、PGlite 也不在兼容计划内。
每个阶段要更新库存的“实施状态”和 API 文档；缺少源码或真实数据库测试的能力
不得通过类型声明、空实现或未执行的 test filter 宣称完成。

## 发布与消费者迁移

Changesets 使用 `fixed: []`、`linked: []`；Packages 没有整体产品版本。
包版本/CHANGELOG/标签由各包变更决定，内部依赖按实际兼容范围跟随。
版本 PR 与 npm publication 分离；首次凭据/Trusted Publisher 配置由维护人完成。
代码仓库创建成功不等于 npm 上已经可安装。

每次 release 前验证实际 tarball：所有 exports 能加载、声明可解析、Drizzle 不重复
打包、许可证齐全，运行时不存在 `workspace:` 或本机路径依赖。
发布只从通过 verify 的提交执行。未经测试的 peer 扩展属于显式兼容变更。

Raypx 在 npm 首发前可消费固定版本的归档产物，并记录来源提交与 SHA256。
正式发布后改为 root catalog 的明确 registry 版本，代码只有 Packages 一份维护来源。
不得通过跨仓库源码路径或永久复制 helper 的方式制造第二个实现。

## 后续扩展准入

新增能力需要：真实源码/规范依据、稳定 API、PostgreSQL 最低版本与 postgres.js/Drizzle peer 声明、事务/解码语义、
至少一个独立消费测试、完整来源记录。可选插件应能在没有对应依赖时导入库根。
与 Drizzle 原生 API 重复的区域优先复用原生实现；原生不足之处再增加能力。
Packages 可以逐步加入 env/logger 等其他通用包，它们与 Drizzle 独立发版，
不因集中维护而共享业务 schema 或形成相互依赖的万能 shared。
