# drizzle-plus 完整能力清单与合并建议

核对日期：2026-10-13。固定上游版本为 `drizzle-plus@1.0.0-rc.8`，提交
[`5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9`](https://github.com/alloc/drizzle-plus/tree/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9)。
许可证为 MIT，作者 Alec Larson。以下库存同时核对 package exports、root
入口、三个方言入口、生成 manifest、扩展模板、低层工具和类型；不以 README
的示例范围代替实际能力范围。

本文件是完整的能力与迁移库存，**不是已实现 API 列表**。表中“计划”表示
尚未在 `@raypx/drizzle` 导出。当前与 drizzle-plus 直接对应的实现只有
`withoutColumns`、`excludedColumn` 和 `excludedColumns`。当前结果解包、JSONB
路径标量与诊断能力另有来源，不表示下列同名上游扩展已移植。

实施范围固定为 PostgreSQL + postgres.js（npm 包 `postgres`），Drizzle 使用
`drizzle-orm/postgres-js`；不兼容 `pg`/node-postgres，也不规划 Bun SQL、PGlite 或其他驱动。
上游三个方言的完整库存全部保留，但 MySQL/SQLite 专有入口、函数、类型与内部实现统一为
**库存保留，当前实施范围外**，不是后续移植承诺。下文“计划”只覆盖通用与 PostgreSQL 能力；
所有同名多方言功能只实现 PostgreSQL 语义。Drizzle 的 `pg-core` 仍是 PostgreSQL 建模接口，
其名称不表示本包支持 npm `pg`。

## 入口、生成方式与兼容性

实际发布入口见固定提交的
[package.json](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/package.json)。

| 上游入口                           | 实际内容                                                                                                 | Toolkit 处理                                                             |
| ---------------------------------- | -------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| `drizzle-plus`                     | 2 个查询配置合并器、4 类语法工具、18 个标量函数、`SQLTimestamp`                                          | 按纯表达式、组合器和类型拆分；不复制入口副作用                           |
| `drizzle-plus/pg`                  | PG 函数与 cast 类型；不自动启用全部扩展                                                                  | PostgreSQL/postgres.js 专属能力保留在 `@raypx/drizzle/postgres`          |
| `drizzle-plus/mysql`               | MySQL 函数与 cast 类型                                                                                   | 库存保留，当前实施范围外；不规划对应入口                                 |
| `drizzle-plus/sqlite`              | SQLite 函数与 cast 类型                                                                                  | 库存保留，当前实施范围外；不规划对应入口                                 |
| `drizzle-plus/{pg,mysql,sqlite}/*` | 生成 feature 的独立构建入口，显式导入启用扩展；`types` 独立发布，`internal` 只有生成源码、不作为构建入口 | 不照搬 wildcard 导出；exports 通配规则不代表每个生成文件都可从发布包导入 |
| `drizzle-plus/utils`               | 13 个低层运行时工具                                                                                      | 逐项重写/内置所需部分，不整包暴露私有查询操作                            |
| `drizzle-plus/types`               | 27 个主类型导出                                                                                          | 计划按可持续维护的公开 Drizzle 类型重建                                  |
| `drizzle-plus/types/*`             | 当前源码中为 `types/json.ts` 的 5 个 JSON 类型                                                           | 可以独立移植，调整 `undefined` 与 JSON 实际序列化语义                    |

生成源清单包含 **19 项**：17 个行为 feature 加 `internal`、`types` 两个支撑
模块。PG 生成 19 项，MySQL 16 项，SQLite 17 项，共 52 个 feature 文件；另有
root generated index 和 3 个方言 index。生成源码含 `@ts-nocheck`，不能把
“文件存在”视为跨 RC 类型兼容的验证。核对依据为
[manifest](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/codegen/manifest.ts)
与
[registry](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/codegen/registry.ts)。

另核对
[rolldown.config.ts](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/rolldown.config.ts)
与
[verify-package.ts](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/scripts/verify-package.ts)：
构建只选 `index`、`types` 与含 `declare module` 的 feature，包验证显式跳过
`internal`。因此完整源码库存的 52 个 feature 文件中，实际独立 feature
发布入口为 49 个，不能把 `internal` 宣称为可导入的发布 API。

上游源码运行时使用 radashi 的 `isPlainObject/isDate/isFunction/select`，
类型使用 `Simplify`；它列在 devDependencies，构建仅 external Drizzle 与
drizzle-plus，所以这些辅助会由构建打入产物。Toolkit 的小型表达式实现
无需继承这项库依赖。生成/构建的 pnpm、Rolldown、dts、tinyglobby 等属于
开发工具，也无需因 fork source 而成为 runtime dependencies。

上游 peer 声明为 `drizzle-orm >=1.0.0-0`；Toolkit 当前只支持其实际测试的
`1.0.0-rc.5-5935859`。广泛 peer 范围不能代替兼容矩阵。原型扩展操作
Database、Table、RelationalQueryBuilder、RelationalQuery、SelectBuilder、
SelectBase、QueryPromise；CTE 特性还替换方言的 `buildWithCTE`。这些全局修改
不进入 Toolkit，采用普通函数、显式 query factory 与消费者提供的
PostgresJsDatabase/PostgresJsTransaction；Sql/TransactionSql 由消费者管理生命周期。

以下表中 `P` 表示 public SQL 构造 API，`I` 表示查询/会话/selection 的内部
结构，`G` 表示全局原型或方法修改。方言列反映上游 manifest/入口，**不等于
Toolkit 已实现或已经验证该方言**；MySQL/SQLite 行为只作为完整上游事实保留。

## 全部 query feature

源码链接集中在固定提交的
[extensions 目录](https://github.com/alloc/drizzle-plus/tree/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/extensions)。

| Manifest feature / 实际 API                                                                   | 上游方言            | 行为、实现依赖                                                                                                                                      | 合并与扩展决定                                                                                                                                                                  |
| --------------------------------------------------------------------------------------------- | ------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `$cursor`; `InferCursor`, `RelationalQueryCursor`                                             | PG / MySQL / SQLite | 根据多列 `orderBy` 生成字典序 OR/AND；缺失 cursor 值按 null；G                                                                                      | 计划纯 keyset predicate；与 better-drizzle `cursor` 共用方向/NULL/复合键模型。必需唯一末尾键与明示 NULL 排序；业务游标签名和 actor/scope 绑定仍由应用负责                       |
| `$findMany`; 配置单参和双参 overload                                                          | 三方言              | 单参保留字面量类型；双参调用 `mergeFindManyArgs`；G                                                                                                 | 计划纯 `defineQuery`/`composeQuery` 类型辅助；去掉 RQB 原型修改。合并与查询执行分开                                                                                             |
| `$select(fields)`                                                                             | 三方言              | 调用 `toSelection(fields,{addAliases:true})`；G/P，部分对象识别使用 I                                                                               | 计划显式 typed selection helper；与 better-drizzle projection/include 的底层选择规则去重                                                                                        |
| `$values`, `$withValues`; `ValuesList`, `ValuesListSubquery`                                  | 三方言              | 数据生成 VALUES SQL、可选首行 cast/表 column decoder、alias/CTE/`inlineParams()`；G/I                                                               | 计划 `valuesList`，核验所有行的相同 key 集合、空行及参数上限；类型名必须 allowlist。一般调用保持参数绑定，inline 仅显式可信场景                                                 |
| `$withMaterialized`, `$withNotMaterialized`                                                   | PG                  | 标记 CTE materialization，并替换 Dialect `buildWithCTE`；G/I                                                                                        | 计划显式 CTE SQL 组合器；优先复用原生 Drizzle 支持，不能修改方言原型。保留 MATERIALIZED / NOT MATERIALIZED 语义                                                                 |
| `$withRecursive`                                                                              | 三方言              | callback 提供 self selection proxy，注入 recursive 标志、decoder，替换 CTE 构造；G/I                                                                | 计划 typed recursive CTE；自引用列清单、SQL/类型一致性、递归终止条件由测试和调用者表达                                                                                          |
| `$without(...fields)`                                                                         | 三方言              | `getColumns(table)` 副本移除字段；G/P                                                                                                               | **已实现为 `withoutColumns`**，普通函数，无原型修改                                                                                                                             |
| `RelationalQuery.as(alias)`, `SelectBuilder.as(alias)`; `RelationalSubquery`                  | 三方言              | 把 RQB 或无 FROM selection 变为可引用子查询并保留 decoder；`_getQuery`、selection、dialect 内部；G/I                                                | 计划明确 `subquery` helper；优先原生 select `.as`，不复刻 RQB 私有 selection 管线                                                                                               |
| `count(filter)`; `CountQueryPromise`                                                          | 三方言              | alias + relational filter 转 SQL；访问 session.objects/dialect；G/I                                                                                 | 计划显式 `countQuery` 适配，复用原生 `count`/`$count`；与 better-drizzle `count`/`exists` 共用表达式。大整数结果保留 string/bigint 选项                                         |
| `create(config)`; `DBCreateConfig`, `CreateQueryResult`, `CreateQueryPromise`                 | **仅 PG**           | 单/多条 insert、skipDuplicates、boolean/SQL returning 投影；用内部 context 和 InsertBuilder；G/I                                                    | 计划 PostgreSQL insert 构造辅助；与 better-drizzle `create/createMany` 合并。保留消费者 Tx，明确 affected rows 与 returning 类型，不能从泛型直接推定实际 driver 返回 number     |
| `findManyAndCount(config)`; `FindManyAndCountResult`                                          | 三方言              | `Promise.all` 同时执行 findMany 与 where-only count，另有两条 `toSQL()`；G/I                                                                        | 计划 `pageAndCount` query-factory 组合；与 better-drizzle `paginate` 去重。消费者显式选择同快照 Tx 或允许两条读不一致，不能默认承诺原子分页                                     |
| `findUnique(config)`; `FindUniqueConfig`                                                      | 三方言              | 按顶层 where keys 找 PK/unique，再执行 `findFirst`；复合约束仅运行时检查；G/I                                                                       | 计划显式唯一键定位，与 better-drizzle `findUnique` 合并；校验值为等值、partial/expression index 条件与约束完整性。上游只检查 key 并不能证明条件唯一                             |
| `fromSingle()`                                                                                | 三方言              | `(select 1) as placeholder` 作为基础行，保证左连接前基底有一行；G/P，字段校验 I                                                                     | 计划 `singleRowSource` 纯 SQL source；API 明确左连接本身仍可能扩成多行                                                                                                          |
| `orThrow(message)`                                                                            | 三方言              | 修改实例 execute，并覆盖 QueryPromise、RQB、SelectBase 原型；空 array 或 null/undefined 抛 DrizzleError；G                                          | 与 better-drizzle `.orThrow()` 去重；当前 `first/inserted` 仅覆盖结果解包的一部分，**不算该原型 API 已移植**。计划 `requireResult/requireRows`，保持数组/单行的区别与可自定错误 |
| `updateMany(config)`; `DBUpdateManyConfig`, `UpdateManyQueryResult`, `UpdateManyQueryPromise` | 三方言              | set callback、relational where、order/limit；PG 用 CTE + ctid + FOR UPDATE，MySQL/SQLite native limit；PG/SQLite returning；G/I                     | 计划明确目标集合的 update factory；与 better-drizzle `updateMany/updateEach` 共用安全写入核心。必须显式允许无 where、明示锁/批量顺序，PG 默认优先稳定主键而非长期持有 ctid      |
| `upsert(config)`; `UpsertSelectQuery`, `DBUpsertConfig`, `UpsertQueryPromise`                 | **PG / SQLite**     | 单/多条或 SELECT 输入；推断/显式 conflict target；current/excluded callback、updateWhere、returning/CTE；修改 SELECT config/`_.selectedFields`；G/I | **仅 excluded 表达式已实现**。完整 upsert 计划重写，与 better-drizzle `upsert/upsertMany` 合并。要求显式 target + update allowlist，不推断写入权限，不为强制返回而隐式更新主键  |
| `withoutFrom()`; `SelectWithoutFrom`                                                          | 三方言              | 手写无 FROM SELECT query subclass，复制 SelectBase descriptors，session prepare/mapper；G/I                                                         | 计划纯 `selectExpressions` SQL 与消费者提供的执行/decoder；原生支持可用时复用。不复制 QueryPromise/SelectBase 内部执行器                                                        |
| `internal`                                                                                    | 三方言              | 私有 context、target/returning、CTE patch、decoder 与子查询辅助；完整清单见下                                                                       | 不形成公开兼容承诺；仅稳定纯 helper 可改写后复用                                                                                                                                |
| `types`; `RelationalQueryBuilder`, `InferColumns`, `RawFieldsToSubquery`                      | 三方言              | 生成方言的 RQB alias、字段推导与 Subquery 类型                                                                                                      | 计划重建 type-only 辅助，避免导出内部 RQB 形状作为公共接口                                                                                                                      |

## Root 语法与合并工具

| API / 类型                                       | 上游行为与依赖                                                                                                                                         | Toolkit 合并决定与状态                                                                                                                  |
| ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------- |
| `mergeFindManyArgs`, `MergeFindManyArgs`         | columns/extras/with 浅合并；limit/offset/order 右侧覆盖；where 调用下项；类型用了 radashi Simplify                                                     | 计划区分配置覆盖与 predicate 组合。返回对象不主动写入 undefined，适配 exactOptionalPropertyTypes                                        |
| `mergeRelationsFilter`, `MergeRelationsFilter`   | 双 OR/RAW 用 AND 分组，双 NOT 递归合并；普通同名字段及已有 AND 可能右侧覆盖                                                                            | 计划重新设计 `andFilters` 和显式 override 模式；**不能直接用于合并强制 tenant/permission filter**，重复条件必须保持逻辑交集             |
| `caseWhen`, `SQLCaseWhen` (`when/else/elseNull`) | 公共 `sql` 组合；忽略 undefined condition；类型累计 THEN/ELSE 联合                                                                                     | 计划纯 SQL CASE builder；缺 ELSE 类型包含 null，空 CASE 明确退化规则                                                                    |
| `nest(query)`                                    | scalar subquery 必须恰好一列；通过 `_getQuery`/`_.selectedFields` 和 decoder 获取结果                                                                  | 计划 `scalarSubquery(query,decoder)` 显式传 decoder 或原生 selection；无行情况必须 nullable，拒绝多列，避免私有 introspection           |
| `toSQL(value)`, `ToSQL`                          | SQLWrapper 直通，其余值用参数绑定                                                                                                                      | 计划纯绑定 helper；修正 string/Date/object 类型，不能把类型声明当作实际 driver 解码                                                     |
| `toSelection(fields,options)`                    | 忽略 undefined，数字/boolean/null SQL literal，string/Date/JSON 参数化，SQL/column/subquery 保留；使用 TypedQueryBuilder/FakePrimitiveParam 与 radashi | 计划显式参数化 selection，非有限数字拒绝或绑定；保留 JSON key，禁止模糊序列化函数/循环对象；不依赖 FakePrimitiveParam 或私有 query 状态 |
| `SQLTimestamp<T>.toDate()`                       | 从 SQL queryChunks 建新 SQL，以 JS Date 解码字符串                                                                                                     | 计划 timestamp decoder，明确日期/时区/非法值策略；不靠宽泛 `new Date()` 掩盖驱动差异                                                    |

## 全部 Root 标量函数（18 个）

这些函数只生成 SQL 与类型；root 入口并不检测数据库方言。除特别说明外
使用 public `sql`/`mapWith`，无需原型补丁，全部为**计划**。迁移时必须同时
测试 PostgreSQL 的 SQL 语法、NULL 与 postgres.js 解码。MySQL/SQLite 差异继续记录，
但不作为当前实施项目或兼容声明。
源码见固定提交的
[functions](https://github.com/alloc/drizzle-plus/tree/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/functions)。

| API                   | 功能                                                   | 移植/扩展要点                                                       |
| --------------------- | ------------------------------------------------------ | ------------------------------------------------------------------- |
| `abs`                 | 绝对值                                                 | nullable、整数/decimal decoder                                      |
| `ceil`                | 向上取整                                               | PostgreSQL numeric/float 重载与结果范围；SQLite math 编译选项仅库存 |
| `floor`               | 向下取整                                               | PostgreSQL numeric/float 重载与结果范围；SQLite math 编译选项仅库存 |
| `sqrt`                | 平方根                                                 | 验证 PostgreSQL 负值/NULL 与结果解码                                |
| `mod`                 | 取模                                                   | PostgreSQL 零除/负数；SQLite `%`/math 支持仅库存                    |
| `power`               | 指数                                                   | PostgreSQL 溢出与精度；SQLite math 支持仅库存                       |
| `round`               | 舍入，可选小数位数                                     | PG numeric/float 重载差异，舍入规则、精度                           |
| `length`              | 字符串长度                                             | PostgreSQL Unicode 字符长度；MySQL 字节/字符差异仅库存              |
| `lower`               | 小写并声明 Lowercase 类型                              | DB collation/locale 不必等价 TS Lowercase，返回类型不能过度精确     |
| `upper`               | 大写并声明 Uppercase 类型                              | 同上，测试 Unicode                                                  |
| `trim`                | 首尾空格                                               | 字符集合与数据库行为明确                                            |
| `substring`           | 1-based 起点，可选长度；发出 FROM/FOR 语法             | 验证 PostgreSQL FROM/FOR；SQLite 函数参数语法差异仅库存             |
| `concatWithSeparator` | `concat_ws`，跳过 NULL value，NULL separator 返回 NULL | 显式引擎版本门槛与参数绑定                                          |
| `coalesce`            | 首个非 NULL 值                                         | 重做 null 联合推导、确认 decoder，不混用不兼容 SQL 类型             |
| `nullif`              | 相等返回 NULL                                          | 上游 return 泛型未总是增加 null，Toolkit 必须保留 nullable 类型     |
| `currentDate`         | current_date，SQLTimestamp 可 `.toDate()`              | session timezone 和 date-only 解码策略                              |
| `currentTime`         | current_time 字符串                                    | timezone/精度与声明一致                                             |
| `currentTimestamp`    | current_timestamp，SQLTimestamp 可 `.toDate()`         | Tx timestamp 语义、时区和 driver 类型                               |

## 全部方言函数与 cast 类型

方言 SQL 不与 better-drizzle facade 重复实现；它们作为表达式层，由未来
facade 或纯查询 helper 调用同一份 PostgreSQL 实现。除已明确实现的
excluded/JSONB path helper 外，通用与 PostgreSQL API 为**计划**；MySQL/SQLite API 为
**库存保留，当前实施范围外**。完整函数、cast key 和语义差异继续列出。

| 方言       | API                                           | 行为与迁移要求                                                                                                     | 实施状态                                              |
| ---------- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------- |
| PG         | `cast`                                        | raw type 名加绑定 value；计划内建类型 allowlist + 显式 trusted SQL type，不能依赖 TS literal 限制阻止运行时注入    | 规划（PostgreSQL/postgres.js）                        |
| PG         | `concat`                                      | NULL 当空值，与 MySQL 语义不同；需 decode/引擎测试                                                                 | 规划（PostgreSQL/postgres.js）                        |
| PG         | `position`                                    | case-sensitive SQL position，未找到 0，nullable                                                                    | 规划（PostgreSQL/postgres.js）                        |
| PG         | `jsonAgg`, `jsonAggNotNull`, `JsonAggOptions` | `jsonb_agg`，可 orderBy/filter，空集 null 或 []；显式 item decoder，修复上游 array decoder 对 null 调用 map 的风险 | 规划（PostgreSQL/postgres.js）                        |
| PG         | `jsonBuildObject`                             | 从字段 map 或 subquery 构造 JSONB 对象、字段 decoder                                                               | 规划（PostgreSQL/postgres.js）                        |
| PG         | `rowToJson`, `RowToJson`                      | 表/view/subquery 转 row_to_json；依赖 `_` selection 与 decoder；上游类型故意省略空行 null，Toolkit 必须恢复 null   | 规划（PostgreSQL/postgres.js）                        |
| PG         | `uuidv7(shift?)`                              | 调用数据库 UUIDv7 function；明确 PostgreSQL 18 能力门槛，PG17 不声明支持                                           | 规划（PostgreSQL/postgres.js）                        |
| PG         | `uuidExtractTimestamp`                        | UUIDv1/v7 timestamp；同样 PostgreSQL 18 能力门槛，返回可 nullable timestamp                                        | 规划（PostgreSQL/postgres.js）                        |
| MySQL      | `cast`                                        | 独立 SQLType 与 cast 语法，不共用 PG 原始 type 名                                                                  | 库存保留，当前实施范围外                              |
| MySQL      | `concat`                                      | 任一 NULL 产生 NULL，与 PG/SQLite 模型分开                                                                         | 库存保留，当前实施范围外                              |
| MySQL      | `position`                                    | position/in，比较受 collation 影响                                                                                 | 库存保留，当前实施范围外                              |
| MySQL      | `jsonArrayAgg`                                | JSON array aggregation + decoder；空集 null、排序可用性需按引擎版本重新声明                                        | 库存保留，当前实施范围外                              |
| MySQL      | `jsonObject`                                  | JSON object construction；字段 key 不应被简单字符过滤改名                                                          | 库存保留，当前实施范围外                              |
| SQLite     | `cast`                                        | integer/real/text/blob 类型与 affinity；不承诺未验证的严格 cast                                                    | 库存保留，当前实施范围外                              |
| SQLite     | `concat`                                      | 上游复用 PG函数；引擎版本测试，不能仅因为源码复用就宣称同语义                                                      | 库存保留，当前实施范围外                              |
| SQLite     | `instr`                                       | string/substr 参数顺序与 position 不同；nullable，未找到 0                                                         | 库存保留，当前实施范围外                              |
| SQLite     | `jsonGroupArray`                              | JSON group aggregation，文本/native JSON 与 item decode 测试                                                       | 库存保留，当前实施范围外                              |
| SQLite     | `jsonObject`                                  | 上游复用 MySQL 构造器；重新检查 JSON subtype、嵌套对象与 driver 返回文本                                           | 库存保留，当前实施范围外                              |
| 三方言各自 | `SQLType`, `SQLTypeToJS`, `InferCastResult`   | 每个入口 3 个 cast 类型；见下方完整 type key 集合。禁止用 number 笼统承诺 bigint/decimal 无损                      | 仅 PG 类型规划；MySQL/SQLite 库存保留，当前实施范围外 |

PG UUID 函数的版本与行为见
[PostgreSQL 18 UUID functions](https://www.postgresql.org/docs/18/functions-uuid.html)；
SQLite 函数的方言形式见
[SQLite core functions](https://www.sqlite.org/lang_corefunc.html)。

cast 类型映射完整 key 集合：

- PG：`int2`, `int4`, `int8`, `smallint`, `integer`, `bigint`, `decimal`,
  `numeric`, `real`, `float4`, `float8`, `double`, `serial`, `bigserial`, `money`,
  `bool`, `char`, `varchar`, `text`, `citext`, `name`, `date`, `time`, `timetz`,
  `timestamp`, `timestamptz`, `interval`, `uuid`, `json`, `jsonb`, `inet`, `cidr`,
  `macaddr`, `bit`, `varbit`。
- MySQL：`tinyint`, `smallint`, `mediumint`, `int`, `bigint`, `float`, `double`,
  `decimal`, `real`, `boolean`, `char`, `varchar`, `text`, `date`, `time`,
  `datetime`, `json`。
- SQLite：`integer`, `real`, `text`, `blob`。

## `./utils` 的全部 13 个导出

固定源码：
[utils.ts](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/utils.ts)。
这些工具目前均未作为 Toolkit 公共 API 移植。

| API                           | 行为 / 依赖                                                                          | 处理                                                                        |
| ----------------------------- | ------------------------------------------------------------------------------------ | --------------------------------------------------------------------------- |
| `getOriginalTableName`        | 读取 `Symbol.for('drizzle:OriginalName')`                                            | 不公开内部 symbol；必要时用 public table metadata                           |
| `getSelectedFields`           | RQB config/table/with/extras、`_.selectedFields`、`_getQuery().selection` 多路径探测 | 重写为显式 selection 输入，不带入 introspection                             |
| `getDecoder`                  | column decoder 或 SQL 私有 `.decoder`，优先 mapFromJsonValue                         | 重写为显式 DriverValueDecoder；JSON/native/SQL driver 解码分开              |
| `getSQL`                      | 调用 query.getSQL()                                                                  | 可复用 SQLWrapper 公共协议，避免冗余公开 facade                             |
| `getDialect`                  | 读取 query.dialect                                                                   | 不移植私有访问，消费者提供 compiler/executor                                |
| `buildRelationalQuery`        | 调用私有 `_getQuery()`                                                               | 不移植；RQB 转 SQL 能力只走验证过的公开入口                                 |
| `createJsonArrayDecoder`      | string JSON.parse + item decoder                                                     | 计划内部复用，增加 null/数组形状检查，不能原样 map null                     |
| `buildJsonProperties`         | selection 字段到 JSON key/value，收集 decoder；key 用字符删除过滤                    | 计划明确字段 map，key 参数化并保留完整 Unicode/标点，不使用删字符避免碰撞   |
| `createJsonObjectDecoder`     | string JSON.parse 后原地解码每项                                                     | 计划 decoder registry，检查 object/null/缺字段，避免意外改写输入对象        |
| `getDefinedColumns`           | 列集合中筛选任意 row 有非 undefined value 的列                                       | 计划内部 write projection，共用显式写入 allowlist；不能推断哪些业务列可更新 |
| `pushStringChunk`             | 把文本合并入 StringChunk.value                                                       | 优先 sql.join 公共组合，避免依赖可变 chunk 内部布局                         |
| `orderSelectedFields`         | flatten 嵌套 table/object selection 成有序 path+field                                | 计划重写 decoder/selection registry，不复制过期 Drizzle 内部工具            |
| `mapSelectedFieldsToDecoders` | 按 alias/末级 key 映射 decoder                                                       | 计划在单一 JSON codec 层去重，嵌套相同末级 key 不能覆盖碰撞                 |

## 主类型、JSON 类型与 feature 附带类型

固定主类型来源：
[types.ts](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/types.ts)。
以下为 **27 个** export type/interface 的完整集合；通用与 PostgreSQL 形态计划重建，
多方言泛型与 MySQL/SQLite 特有形态只保留库存，不代表
Toolkit 当前提供同名兼容导出。

| 分组             | 完整类型集合                                                                                                                                  | 合并方向                                                                             |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ |
| SQL 值/结果      | `SQLValue`, `SQLExpression`, `SQLResult`, `InferSQLNull`                                                                                      | 与 better-drizzle query leaf/表达式类型统一，保留 runtime decode 与类型声明的区别    |
| Query/scalar     | `AnyQuery`, `AnySelectQuery`, `QueryToResult`, `QueryToSQL`, `AnyDialect`                                                                     | 保留公开 SQLWrapper/执行器协议；舍弃 AnySelectQuery 强制 `_.selectedFields` 形状     |
| Relational query | `AnyRelationsFilter`, `AnyDBQueryConfig`, `InferRelationsFilter`, `InferRelations`, `InferOrderBy`, `InferFindManyArgs`, `InferFindFirstArgs` | typed filter compiler/配置组合器共用；精确匹配当前 Drizzle RC，并处理 exact optional |
| Write/returning  | `ReturningClause`, `ReturningResultFields`, `ExtractTable`, `OrderByClause`, `InsertSelectedFields`                                           | 与 better-drizzle writes/returning 合并，约束与字段 allowlist 显式声明               |
| Selection/JSON   | `RawFieldsToSelection`, `ToJsonObject`, `ResultFieldsToSelection`, `SQLFields`, `DecodedFields`, `RowToJson`                                  | 与 PG JSONB/JSON aggregation codec 共用，修复空结果 nullable 与 key 结构             |

`types/json.ts` 的 **5 个**类型：`JSONPrimitive`, `JSONObjectCodable`,
`JSONCodable`, `JSONObject`, `JSON`。源码允许对象值 undefined、readonly
数组和 `toJSON()`；移植时区分“可编码”与“已编码 JSON”，避免把 undefined
或非有限数值误认为数据库 JSON primitive。

feature 文件另外导出的类型/类也全部计入各 feature 行：
`InferCursor`, `RelationalQueryCursor`, `ValuesListSubquery`, `ValuesList`,
`RelationalSubquery`, `CountQueryPromise`, `DBCreateConfig`, `CreateQueryResult`,
`CreateQueryPromise`, `FindManyAndCountResult`, `FindUniqueConfig`,
`RelationalQueryBuilder`, `InferColumns`, `RawFieldsToSubquery`,
`DBUpdateManyConfig`, `UpdateManyQueryResult`, `UpdateManyQueryPromise`,
`UpsertSelectQuery`, `DBUpsertConfig`, `UpsertQueryPromise`, `SelectWithoutFrom`。
root 文件附带 `MergeFindManyArgs`, `MergeRelationsFilter`, `ToSQL`,
`SQLCaseWhen`, `SQLTimestamp`；方言文件附带 `JsonAggOptions` 及每方言的
3 个 cast 类型。

## `internal` 全部导出与 adapter 支撑

`internal` 是生成源码的支撑模块；发布构建与 verify-package 排除了它作为
独立入口，不能仅根据 wildcard exports 假定它可导入。以下 **11 个运行时
导出 + 2 个类型导出**仍全部列入源码能力库存，Toolkit 不承诺兼容其内部
操作方式。固定源码：
[internal.ts](https://github.com/alloc/drizzle-plus/blob/5840bdb4c5b3c7526b7db132f0b14cbe8a89eae9/src/extensions/internal.ts)。

| 导出                             | 用途                                                         | Toolkit 处理                                                                 |
| -------------------------------- | ------------------------------------------------------------ | ---------------------------------------------------------------------------- |
| `getContext`                     | 强制转换 RQB 为 table/schema/tableConfig/dialect/session     | 不移植；显式 PostgreSQL 表/关系 context 与 PostgresJsDatabase/Tx             |
| `getFilterSQL`                   | relationsFilterToSQL + 私有 relation context                 | 计划公开 filter compiler，输入显式 metadata，不探测 DB 内部                  |
| `getReturningFields`             | boolean/include/exclude/SQL callback 返回投影                | 计划纯 returning projection，与 better-drizzle select/omit 规则共用          |
| `getTargetColumns`               | 单列 PK/unique、复合 PK/unique/index 推断                    | 只保留显式约束验证，不按插入字段猜 target；partial/expression index 单独建模 |
| `injectWithSubqueryAddons`       | 替换 withBuilder.as 包装方法                                 | 不移植实例 patch；新建独立 CTE builder                                       |
| `setWithSubqueryAddons`          | WeakMap 保存 CTE 标志并改 Dialect 原型                       | 不移植全局 patch；显式 CTE metadata/SQL                                      |
| `InferDialect`, `ExcludeDialect` | 从 table `_` 推断并排除方言                                  | 保留上游类型库存；仅重建 PostgreSQL 类型，不引入方言泛型                     |
| `excluded`                       | `excluded.identifier` 表达式                                 | **已适配为 `excludedColumn`，增加 `excludedColumns(table,...keys)`**         |
| `sqlNull`                        | SQL null 常量                                                | public sql 可以直接表达，无需单独稳定 API                                    |
| `buildInsertSelect`              | 为缺列填 null/拒绝 generated 列的旧 Drizzle issue workaround | 不照搬；按当前 Drizzle 验证 insert-select 行为再决定 workaround              |
| `buildRelationalQuery`           | `_getQuery()`                                                | 不移植私有调用，与 utils 同名功能去重                                        |
| `createWithSubquery`             | 手建 WithSubquery/SelectionProxyHandler 与 decoder           | 计划 public subquery/explicit selection construction，不绑定私有 handler     |

支撑 adapter 三份文件分别定义 `RelationalQuery` / `InsertQuery` 类型以及
`createInsertBuilder`, `selectRowsToUpdateOrDelete`, `innerJoinMatchedRows`,
`limitUpdateOrDelete`, `setReturningClauseForUpdateOrDelete`, `executeSelect`。
部分方言函数只有 declare 占位，不代表运行时可用。它们位于
`src/internal/dialects/{pg,mysql,sqlite}.ts`，不属于 package 的稳定公开入口。
PG limited update 使用 ctid/锁定 CTE，MySQL/SQLite 使用原生 limit；三个
executeSelect 都依赖 session.prepareQuery 的不同私有参数顺序。Toolkit
改为消费者显式提供 PostgresJsDatabase/PostgresJsTransaction；只实现 PostgreSQL，
不移植 MySQL/SQLite adapter，也不替换原生 DB/Tx。

codegen 的 registry、placeholders、emit、validate 和生成脚本属于开发工具，
不是数据库 runtime API。采用“单份能力定义 + PostgreSQL/postgres.js 版本验证矩阵”，
不导入生成的 @ts-nocheck API 或上游 pnpm 工具链。

## 与 better-drizzle 的统一扩展路线

| 共同能力                              | 唯一实现层                      | 合并规则                                                                                                       |
| ------------------------------------- | ------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| 表字段、select/omit、returning        | 纯 column/selection 层          | `$without` 与 facade projection 共用字段函数；禁止两套 include/exclude 语义                                    |
| JSON scalar/filter/mutation/aggregate | PostgreSQL SQL + 显式 codec 层  | better-drizzle JSON leaf 与 drizzle-plus JSON 构造/聚合共用绑定路径/decoder；路径、对象 key 和 type 名各自验证 |
| findUnique/count/exists               | 原生查询 factory + predicate 层 | 唯一性来自显式约束，count decoder 与 cardinality 共用                                                          |
| cursor/paginate/pageAndCount          | 独立 pagination 层              | 共用 lexicographic SQL、NULL/order/tie-breaker 规则；结果编码与业务签名分离                                    |
| create/updateMany/upsert              | 显式 mutation 层                | 原生 DB/Tx 输入、显式 target/set/returning；nested write 放可选关系编排层                                      |
| orThrow/结果选择                      | 结果层                          | 当前 `first/inserted` 基础上扩展 generic required result，不覆写 query.execute                                 |
| CTE/VALUES/subquery                   | PostgreSQL 表达式层             | Drizzle 原生可完成的行为直接复用；缺失行为通过纯 SQL composition 补足                                          |
| facade/hooks/plugins                  | 可选高层包                      | drizzle-plus 的普通函数可以被 facade 调用；facade 不进入表达式包默认入口，不产生全局修改                       |
| diagnostics/错误                      | diagnostics/errors 独立入口     | 与 better-drizzle 提取共用；不把 query params、predicate、原始 driver cause 加入诊断输出                       |

实施顺序建议：第一阶段发布已经验证的列、excluded、JSONB scalar、结果、
唯一约束与诊断基础；第二阶段补全部纯 scalar/CASE/codec 与 PG JSON 聚合；
第三阶段统一 filter、分页、显式 mutation、VALUES/CTE；第四阶段开发独立
关系编排和可选插件。后续计划 API 在真实 PostgreSQL/postgres.js 测试、类型测试、
pack 消费测试通过前不进入 exports，也不增加 peer 支持范围；没有多方言或多驱动移植阶段。
prepared、事务/savepoint、hook 提交顺序、诊断超时/取消统一按
[合并方案](merge-plan.md) 的 postgres.js 执行核心验证，不复制私有 session 访问。

每一能力完成时同步其状态、来源 commit/许可证、设计决策、公开导出、
PostgreSQL 最低版本、postgres.js/Drizzle 版本与验证证据。不能把“已整理”“准备 fork”写成“功能已完成”。
