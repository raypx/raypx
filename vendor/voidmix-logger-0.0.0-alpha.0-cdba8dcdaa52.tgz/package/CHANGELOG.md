# @voidmix/logger

## 0.0.0-alpha.0

- Add an explicitly initialized evlog runtime with scoped events, safe error summaries, bounded field projection, and framework drain support.
- Add a separate Node stderr JSON drain with injectable output and explicit flush/close lifecycle.
