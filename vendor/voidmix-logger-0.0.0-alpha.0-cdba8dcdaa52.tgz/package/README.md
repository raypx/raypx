# @voidmix/logger

A small, safe boundary around evlog 2.33.1. Applications initialize once explicitly, accumulate one event per operation, and flush before shutdown.

```ts
import { initLogger } from "@voidmix/logger";
import { createStderrDrain } from "@voidmix/logger/node";

const logging = await initLogger({
  service: "example-api",
  environment: "production",
  drain: createStderrDrain(),
});
try {
  const log = logging.createLogger({ operation: "job.run", jobId: "123" });
  log.set({ status: "success", elapsedMs: 42 });
  log.emit();
} finally {
  await logging.close();
}
```

The root entry has no Node imports and does not read environment variables at import time. Initialization lazily imports evlog and owns its process-wide configuration; do not initialize evlog or another runtime concurrently. The package uses an exact ordinary dependency rather than embedding another copy of evlog. `service` and `environment` are required bounded identifiers. A second initialization throws until the first runtime closes.

`createLogger`, `set`, `error`, and `emit` preserve evlog's scoped-event model. `emit` produces at most one event; later writes are ignored. `error(unknown, fields?)` sets the error level and retains only a recognized name and bounded code. It never retains messages, stacks, or causes. `durationMs` measures the evlog scope; use `elapsedMs` for a duration measured by the application. Each scope is independent; callers explicitly inject the runtime rather than relying on ambient request context.

The default fields are `operation`, `requestId`, `method`, `route`, `status`, `statusCode`, `code`, `id`, `jobId`, `runId`, `exitCode`, `durationMs`, `elapsedMs`, `component`, `platform`, `appVersion`, `count`, `enabled`, `mode`, `outcome`, `bufferedBytes`, `byteCount`, `retryCount`, `error`, and `rpc`. `rpc` retains only `system` and `method`. Unknown fields are discarded. `allowedFields` adds explicitly classified application metadata; it cannot disable secret-key rules. Do not place private content in identifiers or arbitrary allowed fields: redaction is defense in depth, not a classifier for every possible secret.

All environments use the same projection and redaction. Secret fields are replaced with `[REDACTED]`; recognized URLs, emails, credentials and bearer tokens in strings are redacted. Strings, nesting, collections, traversal, event size (16 KiB), and pending events (1,024) are bounded. Getters and `toJSON` are never invoked. Values are cloned before asynchronous delivery.

Pass `logging.drain` explicitly to framework integrations such as an evlog handler plugin. It accepts `{ event }`, applies the same safe projection, and synchronously enqueues delivery without returning an output promise. A framework that awaits this drain can complete its response independently of a slow sink; explicit `flush` and `close` still wait for delivery. Do not send raw framework events directly to the output sink. Framework adapters remain application dependencies.

`createStderrDrain()` writes one JSON line per event to stderr and never touches stdout. Tests can provide a caller-owned Node `Writable` via `{ stream }`. `flush()` waits for queued write callbacks; it does not promise remote persistence. `close()` waits for delivery and removes its error listener without ending the stream. No signal handlers, process exit hooks, or automatic initialization are installed.

Sink failures and queue overflow do not throw into `emit` or request handling. They cause `flush` and `close` to reject with a fixed safe error. Applications choose whether shutdown logging failures affect their result. `close` is idempotent and still cleans up the sink after a flush failure. Once closing starts, existing scopes and the drain become no-ops; creating a new scope throws. Always await `close` before process exit; a destination that never completes a write also prevents flush completion.

## Development

```sh
bun run --cwd packages/logger check
bun run --cwd packages/logger test
bun run --cwd packages/logger build
bun run --cwd packages/logger pack:check
```
