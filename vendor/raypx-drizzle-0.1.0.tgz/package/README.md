# @raypx/drizzle

Composable extensions for Drizzle, maintained in [Raypx Toolkit](https://github.com/raypx/toolkit).
Each Toolkit package has its own version and changelog.

This initial package implements a small, tested base. The complete inventories
below include every upstream capability, including features not yet implemented.

## Current API

| Import                       | Exports                                                                                               | Dialect                             |
| ---------------------------- | ----------------------------------------------------------------------------------------------------- | ----------------------------------- |
| `@raypx/drizzle`             | `withoutColumns`                                                                                      | Table projection; PostgreSQL tested |
| `@raypx/drizzle/pg`          | `excludedColumn`, `excludedColumns`, `jsonValue`, `jsonText`, `jsonType`, `jsonNumber`, `jsonBoolean` | PostgreSQL                          |
| `@raypx/drizzle/errors`      | `isUniqueViolation`                                                                                   | PostgreSQL error metadata           |
| `@raypx/drizzle/results`     | `first`, `inserted`                                                                                   | Promise-like row arrays             |
| `@raypx/drizzle/diagnostics` | `buildExplain`, `summarizePlan`, `DrizzleDiagnosticError`                                             | PostgreSQL                          |

Compatibility is currently the exact tested Drizzle version
`1.0.0-rc.5-5935859`. No wider RC, MySQL or SQLite compatibility is implied.
Runtime code uses public Drizzle APIs and has no Raypx, Node or Bun imports.
Drizzle remains a peer dependency, and ESM/declarations are published in `dist/`.

```ts
import { withoutColumns } from "@raypx/drizzle";
import { excludedColumns, jsonNumber } from "@raypx/drizzle/pg";

const memberFields = withoutColumns(members, "createdAt", "updatedAt");
const update = excludedColumns(members, "role", "status", "updatedAt");

await db
  .insert(members)
  .values(input)
  .onConflictDoUpdate({
    target: [members.projectId, members.userId],
    set: update,
  });

const rows = await db.select({ tokens: jsonNumber(usage.data, ["inputTokens"]) }).from(usage);
```

Column omission preserves Drizzle column types and does not change table metadata.
UPSERT mappings use explicitly selected physical column names; the caller supplies
the conflict target and retains ownership of transactions.

## JSONB semantics

Paths are segment arrays: `["settings", "plan.tier"]` addresses the literal key
`plan.tier` below `settings`. Every segment is bound; dot splitting is not used.
Empty paths, NUL bytes, sparse arrays and non-string segments are rejected.

`jsonValue` preserves JSON values. `jsonText` uses PostgreSQL text extraction,
including JSON containers converted to text. `jsonType` distinguishes JSON null
(`"null"`) from a missing path (SQL NULL). `jsonNumber` and `jsonBoolean` return
SQL NULL for missing, JSON null or incorrectly typed values, using CASE before
casting. Numeric result decoding rejects non-finite numbers.

An outer aggregate does not inherit an inner expression's decoder. Consumers
must validate aggregate results explicitly. Accounting or authorization queries
must choose their own policy for malformed stored data; nullable helpers do not
authorize ignoring it.

## Diagnostics

```ts
import { buildExplain, summarizePlan } from "@raypx/drizzle/diagnostics";

const result = await db.execute(buildExplain(statement));
const summary = summarizePlan(result[0]?.["QUERY PLAN"]);
```

Default EXPLAIN returns JSON estimates without executing the statement.
`{ analyze: true, buffers: true }` explicitly executes it and collects buffer
metrics. The library constructs SQL and summarizes plans; the caller owns query
eligibility, connections, transaction access mode, database cancellation and
timeout settings. `summarizePlan` copies only structure and numeric metrics,
with bounded traversal, and excludes predicates, query text and parameters.

`isUniqueViolation(error, constraintName)` recognizes only SQLSTATE `23505` and
the exact supplied constraint, including cycle-safe wrapped causes. It neither
parses messages nor maps to an application's business errors.

## Complete upstream inventory and merge plan

- [drizzle-plus capabilities](docs/drizzle-plus-capabilities.md)
- [better-drizzle capabilities](docs/better-drizzle-capabilities.md)
- [Combined extension design](docs/merge-plan.md)
- [Source provenance and licenses](third-party/NOTICE.md)

The package adapts selected MIT and Apache-2.0 sources. Full source licenses,
copyright and modification notices are distributed alongside the package.

## Development

From the Toolkit root, using Bun 1.4.0:

```bash
bun install --frozen-lockfile
bun run verify
bun run build
bun run pack:check
```

Releases use independent Changesets. See the repository's [release guide](../../README.md).
