# @raypx/drizzle

## 0.1.0

- Extract typed column projections, explicit PostgreSQL UPSERT mappings and
  exact uniqueness classification into a standalone library.
- Add parameterized JSONB expressions with CASE-guarded scalar conversion.
- Add PostgreSQL EXPLAIN construction and sanitized plan summaries.
- Document the complete drizzle-plus and better-drizzle inventories and phased
  merge design, retaining original source commits and license texts.
