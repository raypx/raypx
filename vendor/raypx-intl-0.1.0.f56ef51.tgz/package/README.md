# @raypx/intl

Configurable locale negotiation, ICU translation, Intl formatting, isolated
React providers and catalog testing helpers. Each application supplies its
languages, catalogs and persistence keys. Package version `0.1.0` is prepared
for independent publication; the initial npm release is still pending.

## Configure a locale runtime

```ts
import { createLocaleRuntime } from "@raypx/intl";

export const localeRuntime = createLocaleRuntime({
  locales: ["en", "zh", "de-DE"] as const,
  defaultLocale: "en",
  cookieName: "site_locale",
  cookieMaxAgeSeconds: 60 * 60 * 24 * 365,
});

type Locale = (typeof localeRuntime.locales)[number];

localeRuntime.normalizeLocale("zh-Hans-CN"); // "zh"
localeRuntime.normalizeLocale("de_de"); // "de-DE"
localeRuntime.resolveLocale({ acceptLanguage: "de-DE;q=0.9, en;q=0.8" });
localeRuntime.serializeLocaleCookie("zh", { secure: true });
```

Configuration is copied and frozen. Supported tags match case-insensitively
after canonicalization, and lookup removes regional/script/extension subtags
until a configured tag matches. It does not infer an unconfigured region:
`de` does not match a configuration containing only `de-DE`. `isLocale`
checks exact configured values; `normalizeLocale` returns those values.

Locale resolution prioritizes a valid explicit cookie value, weighted
`Accept-Language` preferences, an optional supported fallback and the configured
default. Malformed tags, zero quality preferences and unsupported languages are
ignored. Cookie parsing reads only the configured name and skips malformed
duplicates. Serialization adds `Path=/`, `SameSite=Lax`, the configured max age
and optional `Secure`; a cookie name must be a valid HTTP token.

## Translate and format

```ts
import { createFormatter, createTranslator } from "@raypx/intl";

const translate = createTranslator({
  locale: "en",
  namespace: "home",
  messages: {
    home: {
      greeting: "Hi {name}",
      count: "{count, plural, one {# item} other {# items}}",
    },
  },
});

translate("greeting", { name: "Ada" }); // "Hi Ada"
translate("count", { count: 3 }); // "3 items"

const formatter = createFormatter("en", {
  timeZone: "Europe/Berlin",
  formats: { number: { money: { style: "currency", currency: "EUR" } } },
});

formatter.number(2, "money"); // "€2.00"
formatter.number(1200, "compact"); // "1.2K"
formatter.relativeTime(-1, "day", "numeric"); // "yesterday"
formatter.list(["A", "B"], "conjunction"); // "A and B"
```

Formatters and translators default to UTC. Named format categories are
`dateTime`, `number`, `list` and `relativeTime`; each accepts arbitrary preset
names. Custom definitions replace individual presets and retain other defaults:
`short`, `compact`, `conjunction` and `numeric`. Unknown standalone formatter
preset names throw `RangeError`. Formatter caching uses locale, timezone and
effective definitions, with a bounded cache of 100 configurations.
Missing messages, invalid ICU syntax and missing interpolation values return the
namespace-qualified message key. Translations support plain scalar values;
React rich-text translation is outside this package's public contract.

## Resolve server locales

```ts
import { createIntlServer } from "@raypx/intl/server";
import { localeRuntime } from "./locale-runtime.js";

const server = createIntlServer(localeRuntime);
server.resolveRequestLocale(request.headers);
server.resolveRequestLocaleHint(request.headers); // undefined without a valid hint
server.resolveConfiguredLocale(process.env.MAIL_LOCALE);
```

The optional hint resolver preserves application-owned defaults such as a mail
recipient's preference. Any object with a `Headers`-compatible `get` method can
be used; the package never imports a framework or reads environment variables.

## Use isolated React providers

```tsx
import {
  createIntlClient,
  createBrowserLocaleStorage,
  createLocalStorageLocaleStorage,
} from "@raypx/intl/client";
import { localeRuntime } from "./locale-runtime.js";

export const {
  I18nProvider,
  AsyncI18nProvider,
  LocaleProvider,
  useLocale,
  useSetLocale,
  useTranslations,
  useFormatter,
} = createIntlClient(localeRuntime);

const cookieStorage = createBrowserLocaleStorage(localeRuntime);
const desktopStorage = createLocalStorageLocaleStorage(localeRuntime, {
  key: "site_locale",
});

const messages = {
  en: { greeting: "Hello" },
  zh: { greeting: "你好" },
  "de-DE": { greeting: "Hallo" },
};

function Root() {
  return (
    <I18nProvider locale="en" messages={messages} storage={cookieStorage}>
      <Greeting />
    </I18nProvider>
  );
}

function Greeting() {
  const translate = useTranslations();
  return <p>{translate("greeting")}</p>;
}
```

Create each client factory once at module scope. Separate factories have
separate contexts and can coexist when embedded applications configure different
languages. `LocaleProvider` supplies locale state without catalogs; the
synchronous `I18nProvider` accepts a complete `MessagesByLocale<Locale>` map.
The async provider accepts the application-owned catalog loader contract and
switches locale/catalog together after loading. Rejected loads can be retried;
overlapping requests preserve the newest selection.

Providers support a custom storage adapter, `timeZone`, `formats` and document
synchronization callback. The package does not modify document metadata unless
the caller provides that callback. Cookie storage follows runtime cookie
settings; localStorage requires an explicit key. Storage access failures are
handled as unavailable persistence. Product-specific migration keys and error
envelopes belong to the application.

## Check catalog parity

```ts
import { assertMessageCatalogParity, extractIcuArguments } from "@raypx/intl/testing";

assertMessageCatalogParity({ greeting: "Hi {name}" }, { greeting: "你好，{name}" }, "en", "zh");
extractIcuArguments("{count, plural, one {# item} other {# items}}"); // ["count"]
```

Recursive key, string/object shape and ICU argument checks produce stable sorted
paths. These catalog validation helpers are isolated in `/testing`. Translation
also uses ICU parsing through `intl-messageformat` to compile messages at
runtime. Type-only public contracts are available in `/types`.

## Compatibility and dependencies

Published entries are ESM with TypeScript declarations, for Node 20+ and Bun;
browser clients require React 19. The root and `/server` entries use native Intl
and `intl-messageformat`, with no React runtime dependency. React is an optional
peer required only when importing `/client`. `@formatjs/icu-messageformat-parser`
provides `/testing` catalog validation and is also used transitively by the ICU
translation backend. The package contains no Raypx catalogs, business
configuration, framework adapters or application package imports.

This package adapts first-party Raypx i18n code into a configurable library.
Third-party libraries remain external dependencies under their own licenses;
their source has not been vendored into this package. Apache-2.0 applies to this
package's implementation.
