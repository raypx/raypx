# @raypx/intl

## 0.1.0

Initial package prepared for independent publication; not yet published to npm.

- Configurable, immutable locale runtimes with weighted language negotiation,
  regional lookup, custom cookies and request resolution.
- ICU translators and cached formatters with UTC defaults and extensible named
  date, number, list and relative-time formats.
- Native Intl formatting and a direct `intl-messageformat` backend keep root and
  server entries usable when React is absent.
- Isolated React provider factories, synchronous and async catalog providers,
  locale hooks and configurable browser storage adapters.
- Recursive catalog parity and ICU argument checks in a separate testing entry.
